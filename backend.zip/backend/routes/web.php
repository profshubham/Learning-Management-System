<?php

use App\Http\Controllers\AuditController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\ComplianceController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\CourseReviewController;
use App\Http\Controllers\DecisionController;
use App\Http\Controllers\GradeController;
use App\Http\Controllers\MaterialController;
use App\Http\Controllers\ProgramController;
use App\Http\Controllers\RecommendationController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\UsersController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::group(["prefix"=>"/api"], function () {
    //Auth
    Route::post("/login",[AuthController::class,"auth"]);
    Route::post("/forgot-password",[AuthController::class,"forgotPassword"]);
    Route::post("/register",[UsersController::class,"addUser"]);
    Route::post("/edit-user",[UsersController::class,"update"]);


    Route::get("/users",[UsersController::class,"getUsers"]);
    Route::get("/get-students",[UsersController::class,"getStudents"]);
    Route::post("/delete-user",[UsersController::class,"delete"]);

    //grades
    Route::post("/add-grade",[GradeController::class,"addGrade"]);
    Route::post("/edit-grade",[GradeController::class,"update"]);
    Route::get("/get-grades",[GradeController::class,"getGrades"]);
    Route::get("/get-grade",[GradeController::class,"getGrade"]);
    Route::get("/get-student-grade",[GradeController::class,"getGrades"]);
    Route::post("/delete-grade",[GradeController::class,"delete"]);

    //programs
    Route::post("/add-program",[ProgramController::class,"addProgram"]);
    Route::post("/edit-program",[ProgramController::class,"update"]);
    Route::get("/get-programs",[ProgramController::class,"getPrograms"]);
    Route::get("/get-program",[ProgramController::class,"getProgram"]);
    Route::get("/get-student-program",[ProgramController::class,"getPrograms"]);
    Route::post("/delete-program",[ProgramController::class,"delete"]);

    //Courses
    Route::post("/add-course",[CourseController::class,"addCourse"]);
    Route::post("/edit-course",[CourseController::class,"update"]);
    Route::post("/enroll-course",[CourseController::class,"enrollCourse"]);
    Route::get("/get-courses",[CourseController::class,"getCourses"]);
    Route::get("/get-course/{courseID}",[CourseController::class,"getCourse"]);
    Route::get("/get-student-courses/{studentID}",[CourseController::class,"getStudentCourses"]);
    Route::get("/get-student-courses-analysis/{studentID}",[CourseController::class,"getStudentCoursesGrades"]);
    Route::get("/get-courses-analysis",[CourseController::class,"getCoursesPerformance"]);
    Route::post("/delete-course",[CourseController::class,"delete"]);


     //Materials
     Route::post("/add-material",[MaterialController::class,"add"]);
     Route::get("/get-course-materials/{courseID}",[MaterialController::class,"courseMaterials"]);
     Route::get("/get-course-material/{courseID}",[MaterialController::class,"courseMaterials"]);
     Route::get("/delete-course-material",[MaterialController::class,"delete"]);


     //Chat
     Route::post("/send-message",[ChatController::class,"sendMessage"]);
     Route::get("/get-messages/{senderID}/{receiverID}",[ChatController::class,"getMessages"]);



     //Reviews

     Route::post("/add-review",[ReviewController::class,"add"]);
     Route::post("/edit-review",[ReviewController::class,"update"]);
     Route::get("/get-reviews",[ReviewController::class,"reviews"]);
     Route::get("/get-review/{ID}",[ReviewController::class,"reviews"]);
     Route::post("/delete-review",[ReviewController::class,"delete"]);

     //Course Reviews

     Route::post("/add-course-review",[CourseReviewController::class,"addReview"]);
     Route::post("/edit-course-review",[CourseReviewController::class,"update"]);
     Route::get("/get-course-reviews",[CourseReviewController::class,"getCourseReviews"]);
     Route::get("/get-course-review/{ID}",[CourseReviewController::class,"getCourseReviews"]);
     Route::post("/delete-course-review",[CourseReviewController::class,"delete"]);

     //Decisions

     Route::post("/add-decision",[DecisionController::class,"addDecision"]);
     Route::post("/edit-decision",[DecisionController::class,"update"]);
     Route::get("/get-decisions",[DecisionController::class,"getDecisions"]);
     Route::get("/get-decision/{ID}",[DecisionController::class,"getDecisions"]);
     Route::post("/delete-decision",[DecisionController::class,"delete"]);

     //Audit

     Route::post("/add-audit",[AuditController::class,"addAudit"]);
     Route::post("/edit-audit",[AuditController::class,"update"]);
     Route::get("/get-audits",[AuditController::class,"getAudits"]);
     Route::get("/get-audit/{ID}",[AuditController::class,"getAudits"]);
     Route::post("/delete-audit",[AuditController::class,"delete"]);


     //Compliance

     Route::post("/add-compliance",[ComplianceController::class,"addCompliance"]);
     Route::post("/edit-compliance",[ComplianceController::class,"update"]);
     Route::get("/get-compliances",[ComplianceController::class,"getCompliances"]);
     Route::get("/get-compliance/{ID}",[ComplianceController::class,"getCompliances"]);
     Route::post("/delete-compliance",[ComplianceController::class,"delete"]);

    //Recommendations

    Route::post("/add-recommendation",[RecommendationController::class,"addRecommendation"]);
    Route::post("/edit-recommendation",[RecommendationController::class,"update"]);
    Route::get("/get-recommendations",[RecommendationController::class,"getRecommendations"]);
    Route::get("/get-recommendation/{ID}",[RecommendationController::class,"getRecommendations"]);
    Route::post("/delete-recommendation",[RecommendationController::class,"delete"]);






});

Route::get('/', function () {
    return view('welcome');
});
