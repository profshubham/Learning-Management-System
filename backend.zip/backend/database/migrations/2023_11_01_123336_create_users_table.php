<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->integer('id', true);
            $table->enum('role', ['user', 'student', 'instructor', 'admin', 'coordinator', 'QA'])->nullable()->default('user');
            $table->string('firstName', 100);
            $table->string('lastName', 100);
            $table->string('email', 100);
            $table->boolean('isDeleted');
            $table->string('password');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
};
