<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller
{
    public function sendMessage(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("chats")->insert([
                "senderID"=>$input["senderID"], 
                "receiverID"=>$input["receiverID"], 
                "message"=>$input["message"],
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            return LoggerController::log(true,"Error");
        }
    }

    public function getMessages($senderID,$receiverID){
        $sql    = "SELECT * FROM chats WHERE (senderID=? AND receiverID=?) OR (senderID=? AND receiverID=?)";
        $data = DB::select($sql,[$senderID,$receiverID,$receiverID,$senderID]);
        return LoggerController::log(false,"success",$data);
    }
}
