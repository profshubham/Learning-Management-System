<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoggerController extends Controller
{
    public static function log($error,$message,$data=[]){
        return (object)["error"=>$error,"message"=>$message,"data"=>$data];
    }
}
