<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class ProgramController extends Controller
{
    public function addProgram(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("programs")->insert([
                "programName"=>$input["programName"], 
                "highlights"=>$input["highlights"], 
                "objectives"=>$input["objectives"], 
                "admissionInformation"=>$input["admissionInformation"],
                "isDeleted"=>0
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            return LoggerController::log(true,"Error");
        }
        
    }
    public function getPrograms()
    {
        $data = DB::table("programs")->where("isDeleted","=",0)->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getProgram($programID)
    {
        $data = DB::table("programs")->where("id","=", $programID)->first();
        return LoggerController::log(false,"success",$data);
    }

    public function getStudentProgram($studentID)
    {
        $sql    = "SELECT * 
                    FROM student_programs 
                    JOIN programs
                    ON programs.id=student_programs.programID 
                    WHERE studentId=?";
        $data = DB::table("student_programs")
            ->join("programs","programs.id","=","student_programs.programID")
            ->where("studentID","=",$studentID)
            ->first();
        return LoggerController::log(false,"success", $this->getProgram($data->programID)->data);
    }

    public function update(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("programs")->where("id","=",$input["programID"])->update([
                "programName"=>$input["programName"], 
                "highlights"=>$input["highlights"], 
                "objectives"=>$input["objectives"], 
                "admissionInformation"=>$input["admissionInformation"],
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            return LoggerController::log(true,"Error");
        }
    }

    public function delete(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("programs")->where("id","=",$input["programID"])->update([
                "isDeleted"=>1
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            return LoggerController::log(true,"Error");
        }
    }
}
