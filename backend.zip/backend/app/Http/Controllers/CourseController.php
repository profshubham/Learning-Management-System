<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CourseController extends Controller
{
    public function addCourse(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("courses")->insert([
                "programID"=>$input["programID"], 
                "name"=>$input["name"], 
                "content"=>$input["content"], 
                "objectives"=>$input["objectives"], 
                "isDeleted"=>0,
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            throw $th;
            return LoggerController::log(true,"Error");
        }
    }

    public function enrollCourse(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("student_courses")->insert([
                "studentID"=>$input["studentID"], 
                "courseID"=>$input["courseID"]
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
    public function getCourses()
    {
        $data = Course::where("isDeleted","=",0)->get();
        return LoggerController::log(false,"success",$data);
    }

    private function getCourseNumberOfStudents($courseID)
    {
        $data = DB::table("student_course_grades")
                        ->where("courseID","=",$courseID)
                        ->get();
        return count($data);
    }

    public function getStudentCoursesGrades($studentID){
        $sql    = "SELECT * 
                        FROM student_course_grades 
                        JOIN courses 
                        ON courses.id=student_course_grades.courseID
                        WHERE student_course_grades.studentID=?";

        $data = DB::table("student_course_grades")
                        ->join("courses","courses.id","=","student_course_grades.courseID")
                        ->where("student_course_grades.studentID","=",$studentID)
                        ->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getCoursesPerformance()
    {
        $sql    = "SELECT * 
                        FROM student_course_grades 
                        JOIN courses 
                        ON courses.id=student_course_grades.courseID";
        
        $data = DB::select($sql);

        
        $gradesMappings = ["A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"];
        $count = 0;
        $labels = [];
        $values = [];
        $ids = [];
        foreach ($data as $key => $value) {
            if(!in_array($value->name,$labels)){
                array_push($labels,$value->name);
                array_push($ids,$value->courseID);
            }

        }

        foreach ($labels as $key => $value) {
            $output = 0;
            foreach ($data as $ke => $val) {
                if (in_array($val->name, $labels)) {
                    foreach ($gradesMappings as $key => $v) {
                        if($v==$val->grade){
                            //get number of students taking the course

                            $output += count($gradesMappings)-$key;
                        }

                    }
                    
                }

            }
           //print_r($ids[$count]);
            $num = $this->getCourseNumberOfStudents($ids[$count]);
            array_push($values, $output/$num);
            $count++;
        }



        return LoggerController::log(false,"success",["values"=>$values,"labels"=>$labels]);
    }

    public function getStudentCourses($studentID)
    {
        $sql    = "SELECT * 
                    FROM student_courses 
                    JOIN courses 
                    ON courses.id=student_courses.courseID
                    WHERE courses.isDeleted=? 
                    AND student_courses.studentID=?";
        $data = DB::select($sql,[0,$studentID]);
        return LoggerController::log(false,"success",$data);
    }

    public function getCourse($courseID)
    {
        $sql    = "SELECT * FROM courses WHERE id=?";
        $data = DB::selectOne($sql,[$courseID]);
        return LoggerController::log(false,"success",$data);
    }

    public function update(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("courses")->where("id","=",$input["courseID"])->update([
                "programID"=>$input["programID"], 
                "name"=>$input["name"], 
                "content"=>$input["content"], 
                "objectives"=>$input["objectives"], 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }

    public function delete(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("courses")->where("id","=",$input["courseID"])->update([
                "isDeleted"=>1,  
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
}
