<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function addReview($programID, $title, $details)
    {
        $sql    = "INSERT INTO reviews(programID,title,details,createdAt) VALUES(?,?,?,?)";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$programID, $title, $details,date("Y-m-d")])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
    public function getReviews()
    {
        $sql    = "SELECT * FROM reviews WHERE isDeleted=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([0]);
        $data = $result->fetchAll();
        return LoggerController::log(false,"success",$data);
    }

    public function getReview($reviewID)
    {
        $sql    = "SELECT * FROM reviews WHERE id=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([$reviewID]);
        $data = $result->fetch();
        return LoggerController::log(false,"success",$data);
    }

    public function update($programID, $title, $details, $reviewID)
    {
        $sql    = "UPDATE reviews SET programID=?,title=?,details=? WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$programID, $title, $details, $reviewID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }

    public function delete($reviewID)
    {
        $sql    = "UPDATE reviews SET isDeleted=1 WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$reviewID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
}
