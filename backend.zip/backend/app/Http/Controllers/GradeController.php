<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GradeController extends Controller
{
    public function addGrade(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("student_course_grades")->insert([
                "instructorID"=>$input["instructorID"], 
                "courseID"=>$input["courseID"], 
                "studentID"=>$input["studentID"], 
                "grade"=>$input["grade"], 
                "feedback"=>$input["feedback"], 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
    public function getGrades()
    {
        $sql    = "SELECT 
                    student_course_grades.id,
                    student_course_grades.grade,
                    student_course_grades.feedback,
                    users.firstName,
                    users.lastName,
                    student_course_grades.courseID,
                    student_course_grades.studentID,
                    student_course_grades.instructorID,
                    courses.name as courseName
                    FROM student_course_grades 
                    JOIN users 
                    ON users.id=student_course_grades.studentID 
                    JOIN courses 
                    ON courses.id=student_course_grades.courseID";

        $data = DB::select($sql,[]);
        return LoggerController::log(false,"success",$data);
    }

    public function getGrade($courseID)
    {
        $sql    = "SELECT * FROM student_course_grades WHERE id=?";
        $data = DB::selectOne($sql,[$courseID]);
        return LoggerController::log(false,"success",$data);
    }

    public function update(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("student_course_grades")->where("id","=",$input["gradeID"])->update([
                "instructorID"=>$input["instructorID"], 
                "courseID"=>$input["courseID"], 
                "studentID"=>$input["studentID"], 
                "grade"=>$input["grade"], 
                "feedback"=>$input["feedback"], 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }

    public function delete(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("student_course_grades")->where("id","=",$input["gradeID"])->update([
                "isDeleted"=>1 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
}
