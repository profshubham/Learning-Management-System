<?php

namespace App\Http\Controllers;

use App\Mail\MailMessage;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class AuthController extends Controller
{
    public $errors;
	public $userData;
	private $firestore;
    private array $data;
    public function auth(Request $request)
    {
        $usersController = new UsersController();
        $data = DB::table("users")->where("email","=",$request->input("email"))->first();
        if (!$data) {
            $this->data["error"]   = true;
            $this->data["message"] = "User not found";
            $this->data["data"]    = [];
        } else if(!Hash::check($request->input("password"), $data->password)){
            $this->data["error"]   = true;
            $this->data["message"] = "Wrong password.";
            $this->data["data"]    = [];
        }else{
            $this->data["error"] = false;
            $this->data["message"] = "Login success";
            $this->data["data"] = $data;
        }
        return LoggerController::log($this->data["error"], $this->data["message"], $this->data["data"]);
    }

    public function userRegistration($firstName, $lastName, $email, $phoneNumber, $password)
    {
        $data = [];
        if (empty($firstName)) {
            return json_encode(["error" => true, "message" => "First name is required"]);
        }
        if (empty($lastName)) {
            return json_encode(["error" => true, "message" => "Last name is required"]);
        }
        if (empty($email)) {
            return json_encode(["error" => true, "message" => "Email is required"]);
        }
        if (empty($phoneNumber)) {
            return json_encode(["error" => true, "message" => "Phone number is required"]);
        }
        if (empty($password)) {
            return json_encode(["error" => true, "message" => "Password is required"]);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return json_encode(["error" => true, "message" => "Please provide a valid email with a valid format eg example@gmail.com"]);
        }

        $defaultProfileImage = "public/images/profileImages/profile.png";

        $subject = "Welcome on board";
        $message = "This email confirms account registraion for " . $firstName;

        Mail::to($email)->send(new MailMessage($email,$subject,$message));
        return LoggerController::log(false,"sadasfdas");

        if ($this->isUserAvailable($email) == true) {
            $data["error"]   = true;
            $data["message"] = "Email Exists.";
            return json_encode($data);
        } else {
            if (!$this->addUser($firstName, $lastName, $email, $phoneNumber, $password)) {
                $data["error"]   = true;
                $data["message"] = "Registration failed.";
            } else {
                
                

                if (!MailMessageController::sendEmail($email, $subject, $message)) {
                    $data["error"]   = true;
                    $data["message"] = "Unable to send email to address " . $email . ". Try again later";
                } else {
                    $data["error"]   = false;
                    $data["message"] = "Successfully registered.";
                }

            }

            return LoggerController::log($data["error"],$data["message"]);
        }


    }

    public function forgotPassword(Request $request)
    {
        $input = $request->input();
        if (!filter_var($input["email"], FILTER_VALIDATE_EMAIL)) {
            return json_encode(["error" => true, "message" => "Please provide a valid email with a valid format eg example@gmail.com"]);
        }
        $usersController = new UsersController();
        if (!$usersController->isUserAvailable($input["email"])) {
            return json_encode(["error" => true, "message" => $input["email"] . " email was not found in our records"]);
        }
        $subject = "Passowrd reset";
        $out     = "";

        $l = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

        for ($i = 0; $i < 8; $i++) {
            $t   = random_int(0, strlen($l) - 1);
            $out .= $l[$t];
        }

        $hashed  = Hash::make($out);
        $message = "Hello, your new password is " . $out;
        if (!$this->updatePassword($hashed, $input["email"])) {
            return json_encode(["error" => true, "message" => "An error occurred, try again later."]);
        }

        if (!MailMessageController::sendEmail($input["email"], $subject, $message)) {
            return LoggerController::log(true,"An error occurred, try again later.");
        }
        
        return LoggerController::log(false,"Check " . $input["email"] . " email for password reset.");
    }
}
