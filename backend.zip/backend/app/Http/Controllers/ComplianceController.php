<?php

namespace App\Http\Controllers;

use App\Models\Compliance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ComplianceController extends Controller
{
    public function addCompliance(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("compliances")->insert([
                "title"=>$input["title"], 
                "details"=>$input["details"], 
                "createdAt"=>date("Y-m-d H:i:s"),
                "isDeleted"=>0,
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
    public function getCompliances()
    {
        $sql    = "SELECT * FROM compliances";
        $data = Compliance::where("isDeleted","=",0)->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getCompliance($complianceID)
    {
        $sql    = "SELECT * FROM compliances WHERE id=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([$complianceID]);
        $data = $result->fetch();
        return LoggerController::log(false,"success",$data);
    }

    public function update( $title, $details, $complianceID)
    {
        $sql    = "UPDATE compliances SET title=?,details=? WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([ $title, $details, $complianceID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }

    public function delete($complianceID)
    {
        $sql    = "UPDATE compliances SET isDeleted=1 WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$complianceID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
}
