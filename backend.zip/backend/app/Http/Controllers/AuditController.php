<?php

namespace App\Http\Controllers;

use App\Models\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuditController extends Controller
{
    public function addAudit(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("audits")->insert([
                "courseID"=>$input["courseID"], 
                "details"=>$input["details"], 
                "createdAt"=>date("Y-m-d H:i:s"),
                "isDeleted"=>0
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            return LoggerController::log(true,"Error");
        }
    }
    public function getAudits()
    {
        $data = DB::table("audits")
                    ->join("courses","courses.id","=","audits.courseID")
                    ->where("audits.isDeleted","=",0)
                    ->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getAudit($auditID)
    {
        $data = Audit::where("id","=",$auditID)->first();
        return LoggerController::log(false,"success",$data);
    }

    public function update(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("audits")->where("id","=",$input["auditID"])->update([
                "courseID"=>$input["courseID"], 
                "details"=>$input["details"]
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }

    public function delete(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("audits")->where("id","=",$input["auditID"])->update([
                "isDeleted"=>1
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
}
