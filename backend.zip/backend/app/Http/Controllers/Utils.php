<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Utils extends Controller
{
    static $appEmail = "allaboutcatapp@gmail.com";
    static $documentsDirectory = "public/course_materials/";
    static function sendEmail($email, $subject, $message)
    {
        $to       = $email;
        $from     = Utils::$appEmail;
        $subject  = "Successfull account registration";
        $headers  = "From:" . $from;

        $headers = array(
            "From: $from",
            "Reply-To: $from",
            "X-Mailer: PHP/" . PHP_VERSION
        );
        $headers = implode("\r\n", $headers);
        try {
            mail($to, $subject, $message,$headers);
            return true;
        }
        catch (\Throwable $th) {
            //throw $th;
            return false;
        }
    }
}
