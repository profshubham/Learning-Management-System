<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CourseReviewController extends Controller
{
    protected function addReview(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("course_reviews")->insert([
                "courseID"=>$input["courseID"], 
                "title"=>$input["title"], 
                "details"=>$input["details"], 
                "createdAt"=>date("Y-m-d H:i:s"), 
                "isDeleted"=>0,
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
    protected function getCourseReviews()
    {
        $sql    = "SELECT * FROM course_reviews WHERE isDeleted=?";
        $data = DB::table("course_reviews")->where("isDeleted","=",0)->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getCourseReview($courseReviewID)
    {
        $sql    = "SELECT * FROM course_reviews WHERE id=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([$courseReviewID]);
        $data = $result->fetch();
        return LoggerController::log(false,"success",$data);
    }

    protected function update(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("course_reviews")->where("id","=",$input["courseReviewID"])->update([
                "courseID"=>$input["courseID"], 
                "title"=>$input["title"], 
                "details"=>$input["details"], 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }

    protected function delete($courseReviewID)
    {
        $sql    = "UPDATE course_reviews SET isDeleted=1 WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$courseReviewID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
}
