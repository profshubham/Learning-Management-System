<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function addExam($courseID, $title, $date)
    {
        $sql    = "INSERT INTO exams(courseID,title,date,createdAt) VALUES(?,?,?,?)";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$courseID, $title, $date, date("Y-m-d")])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
    public function getExams()
    {
        $sql    = "SELECT * FROM exams WHERE isDeleted=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([0]);
        $data = $result->fetchAll();
        return LoggerController::log(false,"success",$data);
    }

    public function getExam($examID)
    {
        $sql    = "SELECT * FROM exams WHERE id=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([$examID]);
        $data = $result->fetch();
        return LoggerController::log(false,"success",$data);
    }

    public function update($courseID, $title, $date, $examID)
    {
        $sql    = "UPDATE exams SET courseID=?,title=?,date=? WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$courseID, $title, $date, $examID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }

    public function delete($examID)
    {
        $sql    = "UPDATE exams SET isDeleted=1 WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$examID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
}
