<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MaterialController extends Controller
{
    public function addMaterial($materialtype, $file, $description, $courseID)
    {
        $sql    = "INSERT INTO course_materials(materialtype, filePath, description, courseID) VALUES(?,?,?,?)";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$materialtype, $file, $description, $courseID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
    public function getMaterials()
    {
        $sql    = "SELECT * FROM course_materials WHERE isDeleted=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([0]);
        $data = $result->fetchAll();
        return LoggerController::log(false,"success",$data);
    }

    public function getCourseMaterials($courseID)
    {
        $sql    = "SELECT * FROM course_materials WHERE isDeleted=? AND courseID=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([0,$courseID]);
        $data = $result->fetchAll();
        return LoggerController::log(false,"success",$data);
    }

    public function getMaterial($materialID)
    {
        $sql    = "SELECT * FROM course_materials WHERE id=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([$materialID]);
        $data = $result->fetch();
        return LoggerController::log(false,"success",$data);
    }

    public function update($materialtype, $file, $description, $courseID, $materialID)
    {
        $sql    = "UPDATE course_materials SET materialType=?,filePath=?,description=?, courseID=? WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$materialtype, $file, $description, $courseID, $materialID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }

    public function delete($materialID)
    {
        $sql    = "UPDATE course_materials SET isDeleted=1 WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$materialID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
}
