<?php

namespace App\Http\Controllers;

use App\Mail\MailMessage;
use App\Models\User;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class UsersController extends Controller
{
    //
    public $errors;
	public $userData;
	private $firestore;

	public function authUser($email, $password)
	{
		
		$data = DB::table("users")->where("email","=",$email)->first();
		print_r($data);
		if (!$data) {
			$this->errors = "User not found";
			return false;
		}

		if (!Hash::check($password, $data->password)) {
			$this->errors = "Wrong password";
			return false;
		}

		$this->userData = $data;
		return true;
	}



	public function isUserAvailable($email)
	{
		$checkSql    = "SELECT * FROM users WHERE email=?";
		$checkResult = DB::table("users")->where("email","=",$email)->first();

		if ($checkResult) {
			return true;
		} else {
			return false;
		}

	}

	public function addUser(Request $request)
	{
		$input = $request->input();
		$hashedPassword = Hash::make($request["password"]);
		$createdAt      = date("Y-m-d H:i:s");
		$role = $input["role"]=="null"?"student":$input["role"];

		if($this->isUserAvailable($input["email"])) {
			return LoggerController::log(true,"User with email ". $input["email"] ." exists");
		}
		if (count($this->getusers()->data) < 1) {
			$role = "admin";
		}

		$subject = "Hello ". $input["firstName"].", Welcome on board.";
        $message = "This email confirms successful account registraion.";

		
        //Mail::to($input["email"])->send(new MailMessage($input["email"],$subject,$message));
		try {
			DB::table("users")->insert([
				"email"=> $input["email"],
				"password"=> $hashedPassword,
				"role"=>$role,
				"firstName"=> $input["firstName"],
				"lastName"=>$input["lastName"],
				"isDeleted"=>false
			]);
			if(!MailMessageController::sendEmail($input["email"],$subject, $message)){
				return LoggerController::log(true,"Unable to send email to ".$input["email"]);
			}
			return LoggerController::log(false,"Success");
		} catch (\Throwable $th) {
			return LoggerController::log(true,"Error");
		}

	}
        

	public function passwordForgot($email)
	{
		$sql    = "SELECT email FROM users WHERE email=?";
		$result = $this->conn()->prepare($sql);
		$result->execute([$email]);
		return $result->fetch();
	}

	public function updatePassword($password, $email)
	{
		$sql    = "UPDATE users SET password=? WHERE email=?";
		
		try{
			DB::table("users")->where("email","=",$email)->update([
				"password"=> $password
			]);
			return LoggerController::log(false,"Success");
        }catch(\Throwable $th) {
			return LoggerController::log(true,"Error");
		}
        
	}

	public function updateProfilePicture()
	{

	}

	public function getUsers()
	{
		$data = User::all();
		return LoggerController::log(false,"success",$data);
	}
	public function getStudents()
	{
		$data = DB::table("users")
			->where("role","=","student")
			->where("isDeleted","=",0)
			->get();
		return LoggerController::log(false,"success",$data);
	}

	public function getInstructors()
	{
		$data = DB::table("users")
				->where("role","=","instructor")
				->where("isDeleted","=",0)
				->get();
		return LoggerController::log(false,"success",$data);
	}
	public function getUser($userID)
	{
		$data = DB::table("users")
				->where("id","=",$userID)
				->where("isDeleted","=",0)
				->first();
		return LoggerController::log(false,"success",$data);
	}

	public function update(Request $request)
	{
		$input = $request->input();
		
		try {
			$sql    = "UPDATE users SET role=?,firstName=?,lastName=?, email=? WHERE id=?";
			DB::table("users")->where("id","=",$input["userID"])->update([
				"role"=>$input["role"],
				"firstName"=>$input["firstName"],
				"lastName"=>$input["lastName"],
				"email"=>$input["email"],
			]);
			return LoggerController::log(false,"Success",$this->getUser($input["userID"])->data);
		} catch (\Throwable $th) {
			return LoggerController::log(true,"Error");
		}
		
        
	}

	public function delete($userID)
	{
		$sql    = "UPDATE users SET isDeleted=1 WHERE id=?";
		$result = $this->conn()->prepare($sql);
		if ($result->execute([$userID])) {
			return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
	}
}
