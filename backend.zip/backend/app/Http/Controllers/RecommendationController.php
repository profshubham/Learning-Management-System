<?php

namespace App\Http\Controllers;

use App\Models\Recommendation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RecommendationController extends Controller
{
    public function addRecommendation(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("recommendations")->insert([
                "title"=>$input["title"], 
                "details"=>$input["details"], 
                "date"=>date("Y-m-d")
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
    public function getRecommendations()
    {
        $sql    = "SELECT * FROM recommendations";
        $data = Recommendation::where("isDeleted","=",0)->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getRecommendation($RecommendationID)
    {
        $sql    = "SELECT * FROM recommendations WHERE id=?";
        $result = $this->conn()->prepare($sql);
        $result->execute([$RecommendationID]);
        $data = $result->fetch();
        return LoggerController::log(false,"success",$data);
    }

    public function update($title, $details, $RecommendationID)
    {
        $sql    = "UPDATE recommendations SET title=?,details=? WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$title, $details, $RecommendationID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }

    public function delete($RecommendationID)
    {
        $sql    = "UPDATE recommendations SET isDeleted=1 WHERE id=?";
        $result = $this->conn()->prepare($sql);
        if ($result->execute([$RecommendationID])) {
            return LoggerController::log(false,"Success");
        }
        return LoggerController::log(true,"Error");
    }
}
