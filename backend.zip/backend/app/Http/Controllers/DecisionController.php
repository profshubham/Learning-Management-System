<?php

namespace App\Http\Controllers;

use App\Models\Decision;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DecisionController extends Controller
{
    public function addDecision(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("decisions")->insert([
                "title"=>$input["title"], 
                "details"=>$input["details"], 
                "createdAt"=>date("Y-m-d H:i:s"),
                "isDeleted"=>0,
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
    public function getDecisions()
    {
        $sql    = "SELECT * FROM decisions WHERE isDeleted=?";
        $data = Decision::where("isDeleted","=",0)->get();
        return LoggerController::log(false,"success",$data);
    }

    public function getDecision($decisionID)
    {
        $sql    = "SELECT * FROM decisions WHERE id=?";
        $data = DB::selectOne($sql, [$decisionID]);
        return LoggerController::log(false,"success",$data);
    }

    public function update(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("decisions")->where("id","=",$input["decisionID"])->update([
                "title"=>$input["title"], 
                "details"=>$input["details"], 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }

    public function delete(Request $request)
    {
        $input = $request->input();
        try {
            DB::table("decisions")->where("id","=",$input["decisionID"])->update([
                "isDeleted"=>1, 
            ]);
            return LoggerController::log(false,"Success");
        }catch(\Throwable $th){
            //throw $th;
            return LoggerController::log(true,"Error");
        }
    }
}
