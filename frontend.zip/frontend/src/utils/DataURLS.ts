export const APPURL="http://127.0.0.1:81/"; //change this line with your domain url
export const BASEURL=`${APPURL}api/`;

export const URLS = {
    getStudents:`${BASEURL}get-students`,
    getUsers:`${BASEURL}users`,
    getMessages:`${BASEURL}get-messages`,
    getStudentCourses:`${BASEURL}get-student-courses/`,
    getPrograms:`${BASEURL}get-programs`,
    getCourses:`${BASEURL}get-courses`,
    getProgramCourses:`${BASEURL}get-program-courses`,
    getStudentGrades:`${BASEURL}get-student-grades`,
    getStudentProgram:`${BASEURL}get-student-program`,
    getDecisions:`${BASEURL}get-decisions`,
    getReviews:`${BASEURL}get-reviews`,
    getCourseMaterials:`${BASEURL}get-course-materials/`,
    getAudits:`${BASEURL}get-audits`,
    getCompliances:`${BASEURL}get-compliances`,
    getGrades:`${BASEURL}get-grades`,
    getRecommendations:`${BASEURL}get-recommendations`,
    getStudentCoursesAnalysis:`${BASEURL}get-student-courses-analysis/`,
    getCoursesAnalysis:`${BASEURL}get-courses-analysis`,
    getCourseReviews:`${BASEURL}get-course-reviews`,
}