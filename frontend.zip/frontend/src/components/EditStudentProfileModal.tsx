import React from 'react'

const EditStudentProfileModal = () => {
    return (
        <div id="edit-profile-popup" className="popup" style={{ display: 'none' }}>
            <div className="popup-content">
                <form id="profile-edit-form">
                    <label >Name:
                        <input type="text" id="name" name="name" placeholder="Enter your name" value="samie Khan" required /></label>

                    <label >Student ID:
                        <input type="text" id="student-id" name="student-id" placeholder="Enter your student ID"
                            value="S123456" required /></label>

                    <label >Program:
                        <input type="text" id="program" name="program" placeholder="Enter your program"
                            value="MSC Computer Science" required /></label>

                    <label>Email:
                        <input type="email" id="email" name="email" placeholder="Enter your email" value="mirkhan@mail.com"
                            required /></label>
                    <button type="submit">Save Changes</button>
                </form>
                <button id="close-popup">Close</button>
            </div>
        </div>
    )
}

export default EditStudentProfileModal