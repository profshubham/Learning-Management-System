import { FormEvent, useEffect, useState } from "react"
import useStore from "../store"
import { Link } from "react-router-dom";
import { BASEURL } from "../utils/DataURLS";


const LoginModal = () => {
    //@ts-ignore
    const isHidden = useStore(state => state.loginHidden)
    //@ts-ignore
    const updateUser = useStore((store) => store.updateUser)
    //@ts-ignore
    const updateLoginHidden = useStore(state => state.updateLoginHidden)

    // form fields
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")
    // form fields errors
    const [usernameError, setUsernameError] = useState(false)
    const [passwordError, setPasswordError] = useState(false)

    // error and normal field css
    const outlineError = { outline: "1px solid red" }
    const outlineNormal = { outline: "unset" }

    const [data,setData] = useState({
        state:false,
        message:""
    });

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        setData({state:false,message:""});
        if (!username) setUsernameError(true)
        if (!password) setPasswordError(true)

        if (!username || !password) {
            alert("All Fields Required");
            return false;
        }else{
            let formData = new FormData();
            formData.append("login","login");
            formData.append("email",username);
            formData.append("password",password);
            fetch(BASEURL+"login",{
                method:"POST",
                body:formData
            })
            .then(req=>req.json())
            .then(res=>{
                console.log(res);
                if(!res.error){
                    localStorage.setItem("user",JSON.stringify(res.data));
                    updateLoginHidden(true)
                    updateUser({loggedIn:true,data:res.data});
                    setPassword("")
                    setUsername("")
                }else{
                    setData({
                        state:true,
                        message:res.message
                    })
                }
                
            }).catch(e=>{
                console.log(e);
            })
            

        }

    }

    useEffect(() => {
        if (passwordError && password) setPasswordError(false)
        if (usernameError && username) setUsernameError(false)
    }, [username, password])



    return (

        <div style={isHidden ? { display: 'none' } : { display: 'flex' }} id="loginPopup" className="popup">
            <div className="popup-content">
                <span onClick={() => {
                    setData({
                        state:false,
                        message:""
                    });
                    updateLoginHidden(true)
                    console.log("login kk");
                    console.log(isHidden);
                    

                }} className="close" id="closeLogin">&times;</span>
                <h2>Login</h2>
                {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                <form method="post" onSubmit={handleSubmit}>
                    <label >Username:
                        <input onChange={e=>setUsername(e.target.value)} value={username} style={usernameError ? outlineError:outlineNormal} type="text" id="username" name="username" /></label>
                    <label >Password:
                        <input onChange={e=>setPassword(e.target.value)} value={password} style={passwordError ? outlineError:outlineNormal} type="password" id="password" name="password" /></label>

                    <Link onClick={() => {
                        updateLoginHidden(true)
            }} style={{ textDecoration: "underline", color: "blue" }} to="/forget-pwd">Forgot Password?</Link>
                    <button style={{display:"block"}} type="submit">Log In</button>
                </form>
            </div>
        </div>
    )
}

export default LoginModal