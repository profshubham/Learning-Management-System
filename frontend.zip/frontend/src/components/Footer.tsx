import React from 'react'

const Footer = () => {
    return (
        <footer>
            <p>&copy; 2023 Academic Program</p>
        </footer>
    )
}

export default Footer