import chatIcon from '../assets/chat-icon.png'
import useStore from '../store';
import {useState,useEffect} from "react";
import { BASEURL, URLS } from '../utils/DataURLS';
import { SENTAUDIOFILE } from '../utils/AudioFiles';


const Chat = () => {
    const [activeTab,setActivetab] = useState(null);
    const [selectedIndex,setSelectedIndex] = useState(null);
    //@ts-ignore
    const chatOpen = useStore(state => state.chatOpen)
    //@ts-ignore
    const UpdatechatOpen = useStore(state => state.updateChat)
    //@ts-ignore
    const user = useStore((store) => store.user);

    const [message,setMessage] = useState("");

    const [data,setData] = useState({
        results:[],
        error:false,
        message:""
    });

    const [messages,setMessages] = useState({
        results:[],
        error:false,
        message:""
    });
    const fetchUsers = async ()=>{
        let request = await fetch(URLS.getUsers,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
        console.log(response);
    }

    const sendMessage = ()=>{
        if(message == ""){
            return;
        }

        let formData = new FormData();
        formData.append("send-message","send");
        formData.append("senderID",user.data.id);
        //@ts-ignore
        formData.append("receiverID",data.results[selectedIndex].id);
        formData.append("message",message);

        fetch(BASEURL+"send-message",{
            method:"POST",
            body:formData
        })
        .then(req=>req.json())
        .then(res=>{
            console.log(res);
            let audio = new Audio(SENTAUDIOFILE);
            audio.play();
            setMessage("");
            fetchMessages();
        }).catch(e=>{
            console.log(e);
        })
    }

    const fetchMessages = async ()=>{
        //@ts-ignore
        let request = await fetch(`${URLS.getMessages}/${user.data.id}/${data.results[selectedIndex].id}`,
            {method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setMessages({error:response.error,message:response.message,results:response.data})
        console.log(response);
    }

    useEffect(()=>{
        fetchUsers();
        if(selectedIndex !== null){
            fetchMessages();
        }
        if(!user.loggedIn){
            setActivetab(null);
            setSelectedIndex(null);
        }
    },[user.loggedIn,selectedIndex]);
    return (
        <div style={{
            display:user.loggedIn?"flex":"none",
        }} >
            <div onClick={() => {
                UpdatechatOpen(!chatOpen);

            }} className="chat-icon" id="openChat">
                <img src={chatIcon} alt="Chat Icon" />
            </div>
            <div style={chatOpen ? {display:'block'}: {display:"none"}} className="chat-popup">

                <div className="chat-header">
                    <span onClick={() => {
                        UpdatechatOpen(!chatOpen);
                        setActivetab(null);
                    }} className="close-chat">&times;</span>
                    {/*@ts-ignore*/}
                    <span color='#ffffff' >{selectedIndex==null?"Chat":data.results[selectedIndex].firstName}</span>
                    <span color='#ffffff' onClick={()=>{
                        //@ts-ignore
                        setActivetab(1);
                        }} >Users</span>
                </div>
                {
                    activeTab==null?
                    <div className="chat-messages">
                        <div className="chat-message sent">
                            Click on users icon to start a conversation.
                        </div>
                    </div>:
                    activeTab==0?
                    <>
                    <div className="chat-messages">
                        {
                            messages.results.length>0?
                            messages.results.map((item,index)=>{
                                //@ts-ignore
                                if(item.senderID == user.data.id){
                                    return <div className={`chat-message received`}  >
                                            {/*@ts-ignore*/}
                                            {item.message}
                                        </div>
                                }
                                
                                //@ts-ignore
                                if(item.senderID == data.results[selectedIndex].id){
                                    return <div className={`chat-message sent`}  >
                                            {/*@ts-ignore*/}
                                            {item.message}
                                        </div>
                                }

                            }):
                            <div className='chat-messages'>
                                No messages yet
                            </div>
                        }

                    </div>
                    <div className="chat-input">
                        <input type="text" placeholder="Type your message..." onChange={(e)=>setMessage(e.target.value)} />
                        <button onClick={()=>sendMessage()} >Send</button>
                    </div>
                    </>:
                    <div className='chat-messages' >
                        {
                            data.results.length>0?
                            data.results.map((item,index)=>{
                                //@ts-ignore
                                return user.data.id==item.id?<></>:<div onClick={()=>{
                                    //@ts-ignore
                                    setActivetab(0);
                                    //@ts-ignore
                                    setSelectedIndex(index)
                                }} className="chat-message sent">
                                    {/*@ts-ignore*/}
                                    {item.firstName} {item.lastName}</div>
                            }):
                            <div className="chat-message sent">
                                No users found.
                            </div>
                        }
                    </div>
                }
                
            </div>
        </div>
    )
}

export default Chat