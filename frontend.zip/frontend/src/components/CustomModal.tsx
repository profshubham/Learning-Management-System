import React from 'react'
//@ts-ignore
const CustomModal = ({setModalShown,modalShown,children,heading=""}) => {
  return (
    <div style={{display: modalShown?'flex':'none' }} id="loginPopup" className="popup">
        <div className="popup-content">
                <span onClick={() => {
                    setModalShown(false)

                }} className="close" id="closeLogin">&times;</span>
                {
                  heading?
                  <h2>{heading}</h2>:
                  <></>
                }
                {children}
            </div>
        </div>
  )
}

export default CustomModal;