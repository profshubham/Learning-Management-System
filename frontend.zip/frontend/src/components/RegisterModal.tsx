import { Link } from 'react-router-dom'
import useStore from '../store'
import { FormEvent, useEffect, useState } from 'react'
import { BASEURL } from '../utils/DataURLS'

const RegisterModal = () => {
  const isHidden = useStore(store => store.registerHidden)
  const updateRegisterHidden = useStore((store) => store.updateRegisterHidden)
  const updateForgotPwdHidden = useStore((state) => state.updateForgotPwdHidden)

  // form fields
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  // form fields errors
  const [firstNameError, setFirstNameError] = useState(false)
  const [lastNameError, setLastNameError] = useState(false)
  const [emailError, setEmailError] = useState(false)
  const [passwordError, setPasswordError] = useState(false)

  // error and normal field css
  const outlineError = { outline: "1px solid red" }
  const outlineNormal = { outline: "unset" }

const [data,setData] = useState({
        state:false,
        message:""
    });
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!firstName) setFirstNameError(true)
    if (!lastName) setLastNameError(true)
    if (!email) setEmailError(true)
    if (!password) setPasswordError(true)
    
    if (!firstName || !lastName || !email || !password) {
      alert("All Fields Required")
      return;
    }

else{


  let formData = new FormData();
  formData.append("register","register");
  formData.append("firstName",firstName);
  formData.append("lastName",lastName);
  formData.append("email",email);
  formData.append("role",null);
  formData.append("password",password);
  fetch(BASEURL+"register",{
      method:"POST",
      body:formData
  })
  .then(req=>req.json())
  .then(res=>{
      console.log(res);
      if(!res.error){
      updateRegisterHidden(true)
      setEmail("")
      setPassword("")
      setFirstName("")
      setLastName("")
      }else{
        setData({
                  state:true,
                  message:res.message
          })
      }
  }).catch(e=>{
      console.log(e);
  })
  
}
  }

  useEffect(() => {
    if (firstNameError && firstName) setFirstNameError(false)
    if (lastNameError && lastName) setLastNameError(false)
    if (emailError && email) setEmailError(false)
    if (passwordError && password) setPasswordError(false)
  }, [firstName, lastName, email, password])


  return (
    <div style={isHidden ? { display: 'none' } : { display: 'flex' }} id="registerPopup" className="popup">
      <div className="popup-content">
        <span onClick={() => {
          updateRegisterHidden(true)
          console.log('clicked');

        }} className="close" id="closeRegister">&times;</span>
        <h2>Register</h2>
        {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
        <form onSubmit={handleSubmit}>
          <label >First Name:
            <input style={firstNameError ? outlineError : outlineNormal} value={firstName} onChange={e => setFirstName(e.target.value)} type="text" id="firstName" name="firstName" /></label>

          <label >Last Name:
            <input style={lastNameError ? outlineError : outlineNormal} value={lastName} onChange={e => setLastName(e.target.value)} type="text" id="lastName" name="lastName" /></label>

          <label style={{ display: "block" }}>Email:
            <input value={email} onChange={e => setEmail(e.target.value)} style={emailError ? {  display: "block", width: "100%", outline: "1px solid red"  } : {  outline: "unset" , display: "block", width: "100%" }} type="email" id="email" name="email" /></label>

          <label >Password:
            <input style={passwordError ? outlineError : outlineNormal} value={password} onChange={e => setPassword(e.target.value)} type="password" id="password" name="password" /></label>
          
          <div className="form-options">
            <label>
              <input type="checkbox" id="rememberMe" name="rememberMe" />
              Remember Me
            </label>
            
          </div>

          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  )
}

export default RegisterModal