
const ReviewModal = () => {
    return (
        <div id="myModal" className="modal">
            <div className="modal-content">
                <h2>Add New Review</h2>
                <form>
                    <label >Review Title:
                        <input type="text" id="reviewTitle" name="reviewTitle" required /></label><br /><br />

                    <label >Review Date:
                        <input type="date" id="reviewDate" name="reviewDate" required /><br /><br /></label>

                    <label >Review Details:
                        <textarea id="reviewDetails" name="reviewDetails" rows={4} required></textarea></label><br /><br />

                    <input type="submit" value="Add Review" />
                </form>
                <button >Close</button>

            </div>
        </div>
    )
}

export default ReviewModal