import React,{useState} from 'react';
import useStore from '../store'
import CustomModal from './CustomModal';
import { EditUser } from '../pages/Users';
//@ts-ignore
const UserProfile = () => {
    //@ts-ignore
    const [modalShown,setModalShown] = useState(false);
    //@ts-ignore
    const user = useStore((store) => store.user)
    return (
        <div className="container">
            <h2>{user.data?.role?.toUpperCase()} UserProfile</h2>
            <div id="admin-details">
                <p><strong>Name:</strong>{user.data.firstName} {user.data.lastName}</p>
                <p><strong>Email:</strong> {user.data.email}</p>
            </div>
            <button id="edit-button" onClick={()=>setModalShown(true)} >Edit</button>

            <CustomModal 
                modalShown={modalShown} 
                setModalShown={setModalShown} 
                heading='Edit Profile'
                >
                <EditUser user={user.data} setModalShown={setModalShown} isEditingSelf={true} />
            </CustomModal>
        </div>
    )
}



export default UserProfile