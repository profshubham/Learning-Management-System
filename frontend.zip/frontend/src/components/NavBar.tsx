import { Link } from 'react-router-dom'
import logo from '../assets/logo.jpeg'
import useStore from '../store'
import { UserContext } from '../contexts';
import {useContext,useState} from "react";
const NavBar = () => {
    const [mobileMenu,setMobileMenu] = useState(false);
    //@ts-ignore
    const user = useStore((store) => store.user)
    //@ts-ignore
    const updateUser = useStore((store) => store.updateUser)
    //@ts-ignore
    const registerHidden = useStore((store) => store.updateRegisterHidden)
    //@ts-ignore
    const loginHidden = useStore((store) => store.updateLoginHidden)
    const logout = ()=>{
        try {
            //@ts-ignore
            //useStore((store) => store.removeUser);
            updateUser({loggedIn:false,data:{}});
            localStorage.removeItem("user");
        } catch (error) {
            console.log(error);
            
        }
        
    }
    const userData = useContext(UserContext);

    const navUsers = [
        {
            "student": [
                { path: "student", name: 'Student Home' },
                { path: "program", name: 'Academic program' },
                { path: "student-objectives", name: 'Program Objectives' },
                { path: "student-courses", name: 'Courses' },
                { path: "exams", name: 'Exams' },
                { path: "materials", name: 'Course Materials' },
                { path: "results", name: 'Exam Result' },
                { path: "reports", name: 'Reports' },
                { path: "communications", name: 'communication' },
            ],
        },
        {
            "instructor": [
                { path: "instructor", name: 'Program Instructor Home' },
                { path: "assessment", name: 'Assessment' },
                { path: "students", name: 'students Management' },
                { path: "recommendations", name: 'Recommendations' },
                { path: "compliance", name: 'Compliance' },
                { path: "courses", name: 'courses' },
                { path: "progress", name: 'Student Progress' },

            ],
        },
        {
            "admin": [
                { path: "admin", name: 'Administrator Home' },
                { path: "objectives", name: 'Manage Program Objectives' },
                { path: "settings", name: 'Admin Activities' },
                { path: "recommendations", name: 'Recommendations' },
                { path: "compliance", name: 'Compliance' },
                { path: "users", name: 'Manage Users Accounts' },

            ],
        },
        {
            "coordinator": [
                { path: "coordinator", name: 'Program Coordinator Home' },
                { path: "objectives", name: 'Program Objectives' },
                { path: "reviews", name: 'Program Reviews' },
                { path: "recommendations", name: 'Recommendations' },
                { path: "compliance", name: 'Compliance' },
                { path: "students-contact", name: 'students contact' },
                { path: "decisions", name: 'Strategic Decisions' },

            ],
        },
        {
            "QA": [
                { path: "qa", name: 'Quality Assurance Officer Home' },
                { path: "processes", name: 'QA processes' },
                { path: "reviews", name: 'Courses Review' },
                { path: "audit", name: 'Course Audit' },
                { path: "recommendations", name: 'Recommendations' },
                { path: "compliance", name: 'Compliance' },
                { path: "progress", name: 'Reports' },

            ]
        },
        {
            "default": [
                { path: "/", name: 'Home' },
                { path: "news", name: 'News/Updates' },
                { path: "contacts", name: 'Contact Us' },
                { path: "about", name: 'About Us' },
            ],
            "user": [
                { path: "/", name: 'Home' },
                { path: "news", name: 'News/Updates' },
                { path: "contacts", name: 'Contact Us' },
                { path: "about", name: 'About Us' },
            ]
        }
    ];
    const userType = user?.data?.role;
    console.log(user);
    
    let userNavigationOptions = []

    let  navigationOptions = []
    if (userType){
        //@ts-ignore
        userNavigationOptions = navUsers.find(navUser => navUser.hasOwnProperty(userType));
        navigationOptions = userNavigationOptions[userType];
    }
    else{
        //@ts-ignore
        userNavigationOptions = navUsers.find(navUser => navUser.hasOwnProperty('default'))
        //@ts-ignore
        navigationOptions = userNavigationOptions['default'];

    }



    console.log(navigationOptions);
    
    return (
        <div>
            <div className="header">
                <div className="logo">
                    <Link to="/">
                        <img src={logo} alt="Institution Logo" />
                    </Link>

                </div>
                <div className="mobile-menu-button">
                    <button className="dropbtn" onClick={()=>setMobileMenu(!mobileMenu)} >&#9776;</button>
                    <div className="dropdown-content" style={{
                        display:mobileMenu?"flex":"none"
                    }} >
                        {
                            navigationOptions.map(navItem => (<li 
                                    key={navItem.path} 
                                    className='a'
                                    onClick={()=>setMobileMenu(false)} >
                                        <Link to={navItem.path}>{navItem.name}</Link>
                                    </li>))
                        }

                    </div>
                </div>

                <nav className="main-nav">
                    <ul>
                        {navigationOptions.map(navItem => (<li key={navItem.path}><Link to={navItem.path}>{navItem.name}</Link></li>))}
                    </ul>
                </nav>
               {userType? <button onClick={()=>{
                try{
                    logout()
                }
                catch (e){
                    console.log(e);
                    
                }
               }}>logout</button>: <div className="user-options">
                        {/*<select onChange={(e) => { updateUser({ name: "samie", email: "samie@gmail.com", type: e.target.value }) }} value={userType}  style={{ background: "#444", opacity: 1, color:"white" }}>
                            <option value="">User</option>
                            <option value="student">Student</option>
                            <option value="instructor">Instructor</option>
                            <option value="admin">Admin</option>
                            <option value="coordinator">Coordinator</option>
                            <option value="QA">Quality Assurance Officer</option>
                        </select>*/}
                    <div className="user-dropdown">
                        <button className="dropbtn"><span className="icon">🔑</span></button>
                        <div className="dropdown-content" style={{ background: "#444", opacity: 1 }}>
                            < button onClick={() => {
                                loginHidden(false)

                            }} id="loginLink">Log In</button>
                            <button onClick={() => {
                                registerHidden(false)

                            }}
                                id="registerLink">Register</button>
                        </div>
                    </div>
                </div>}
            </div>
        </div>
    )
}

export default NavBar