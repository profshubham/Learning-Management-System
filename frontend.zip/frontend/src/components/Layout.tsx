import NavBar from './NavBar'
import Footer from './Footer'
import Chat from './Chat'
import { Outlet } from 'react-router'
import LoginModal from './LoginModal'
import RegisterModal from './RegisterModal'

const Layout = () => {
  return (
    <>
      <NavBar />
      <Outlet />
      <Chat/>
      <LoginModal/>
      <RegisterModal/>
      <Footer />
    </>
  )
}

export default Layout