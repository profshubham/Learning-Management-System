import Layout from './components/Layout'
import { Route, Routes, json } from 'react-router'
import { BrowserRouter } from 'react-router-dom'
import Homepage from './pages/Homepage.js'
import Accounts from './pages/Accounts.js'
import Courses from './pages/Courses.js'
import Exams from './pages/Exams.js'
import Programs from './pages/Programs.js'
import Reports from './pages/Reports.js'
import ContactUs from './pages/ContactUs.js'
import AboutUs from './pages/AboutUs.js'
// styles
import './assets/styles/admin.css'
import './assets/styles/coordinator.css'
import './assets/styles/program.css'
import './assets/styles/courses.css'
import './assets/styles/instructor.css'
import './assets/styles/instructor.css'
import './assets/styles/qa.css'
import './assets/styles/student.css'
import './assets/styles/popup.css'
import './assets/styles/home.css'
// pages
import Admin from './pages/Admin.js'
import Assesment from './pages/Assesment.js'
import Audit from './pages/Audit.js'
import Communication from './pages/Communication.js'
import Compliance from './pages/Compliance.js'
import Coordinator from './pages/Coordinator.js'
import CourseMaterial from './pages/CourseMaterial.js'
import Decisions from './pages/Decisions.js'
import EditProfile from './pages/EditProfile.js'
import Instructor from './pages/Instructor.js'
import Objectives from './pages/Objectives.js'
import Processes from './pages/Processes.js'
import Qa from './pages/Qa.js'
import Recommendations from './pages/Recommendations.js'
import Results from './pages/Results.js'
import Settings from './pages/Settings.js'
import Student from './pages/Student.js'
import Users from './pages/Users.js'
import News from './pages/News.js'
import Students from './pages/Students.js'
import StudentsContact from './pages/StudentsContact.js'
import Review from './pages/Review.js'
import Progress from './pages/Progress.js'
import QaReports from './pages/QaReports.js'
import ForgotPwd from './pages/ForgotPwd.js'
import { UserContext } from './contexts';
import { useEffect, useMemo, useState } from 'react'
import useStore from './store.js'
import StudentObjectives from './pages/StudentObjectives.js'
import StudentCourses from './pages/StudentCourses.js'
import Materials from './pages/Materials.js'
function App() {
  //@ts-ignore
  const updateUser = useStore((store) => store.updateUser)
    const [userData,setUserData] = useState({loggedIn:false,data:{}});
    const userDataProvider = useMemo(()=>[userData,setUserData],[userData,setUserData]);
    useEffect(()=>{
        let user = localStorage.getItem("user");
        if(user !== null){
          let userInfo = JSON.parse(user);
          setUserData({loggedIn:true,data:userInfo});
          updateUser({loggedIn:true,data:userInfo});
        }
    },[]);
  return (
    <>
    <UserContext.Provider value={userDataProvider} >
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" index element={<Homepage />} />
            <Route path="/accounts" element={<Accounts />} />
            <Route path="/courses" element={<Courses />} />
            <Route path="/exams" element={<Exams />} />
            <Route path="/program" element={<Programs />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contacts" element={<ContactUs />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/assessment" element={<Assesment />} />
            <Route path="/audit" element={<Audit />} />
            <Route path="/communications" element={<Communication />} />
            <Route path="/compliance" element={<Compliance />} />
            <Route path="/coordinator" element={<Coordinator />} />
            <Route path="/course-material" element={<CourseMaterial />} />
            <Route path="/materials/:id" element={<Materials />} />
            <Route path="/students-contact" element={<StudentsContact />} />
            <Route path="/decisions" element={<Decisions />} />
            <Route path="/edit-profile" element={<EditProfile />} />
            <Route path="/instructor" element={<Instructor />} />
            <Route path="/objectives" element={<Objectives />} />
            <Route path="/student-objectives" element={<StudentObjectives />} />
            <Route path="/student-courses" element={<StudentCourses />} />
            <Route path="/process" element={<Processes/>} />
            <Route path="/qa" element={<Qa />} />
            <Route path="/Recommendations" element={<Recommendations/>} />
            <Route path="/reports" element={<Reports/>} />
            <Route path="/results" element={<Results/>} />
            <Route path="/settings" element={<Settings/>} />
            <Route path="/student" element={<Student/>} />
            <Route path="/users" element={<Users/>} />
            <Route path="/news" element={<News/>} />
            <Route path="/students" element={<Students/>} />
            <Route path="/materials" element={<CourseMaterial/>} />
            <Route path="/reviews" element={<Review/>} />
            <Route path="/progress" element={<Progress/>} />
            <Route path="/qa-reports" element={<QaReports/>} />
            <Route path="/processes" element={<Processes/>} />
            <Route path="/forget-pwd" element={<ForgotPwd/>} />
          </Route>
        </Routes>
      </BrowserRouter>
      </UserContext.Provider>
    </>
  )
}

export default App
