import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';
import { BASEURL, URLS } from '../utils/DataURLS';
import CustomModal from '../components/CustomModal';

const grades = ["A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"];
const Students = () => {
    const navigate = useNavigate();
    const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const [data,setData] = useState({
        results:[],
        error:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        courseID:null,
        feedback:"",
        grade:grades[0],
        studentID:null
    });
    const [selected,setSelected] = useState(null);

    

    const [studentCourses,setStudentCourses] = useState({
        results:[],
        error:false,
        message:""
    });
const fetchStudents = async ()=>{
    let request = await fetch(URLS.getStudents,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setData({error:response.error,message:response.message,results:response.data});
    fetchCourses(response.data[0].id);
    console.log(response);
}

//@ts-ignore
const fetchCourses = async (studentID)=>{
    let request = await fetch(`${URLS.getStudentCourses}${studentID}`,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setStudentCourses({error:response.error,message:response.message,results:response.data});
    setSelected(response.data[0]);
    console.log(response);
}

const [studentGrades,setStudentGrades] = useState({
    results:[],
    error:false,
    message:""
})

//@ts-ignore
const fetchStudentGrades = async ()=>{
    let request = await fetch(`${URLS.getGrades}`,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setStudentGrades({error:response.error,message:response.message,results:response.data});
    console.log(response);
}

  //@ts-ignore
  const user = useStore((store) => store.user);

  //@ts-ignore
  const addGrade = async (e)=>{
    e.preventDefault();
    let formData = new FormData();
    formData.append("add-grade","edit");
    formData.append("courseID",credentials.courseID??studentCourses.results[0].id);
    formData.append("studentID",credentials.studentID??data.results[0].id);
    formData.append("instructorID",user.data.id);
    formData.append("grade",credentials.grade);
    formData.append("feedback",credentials.feedback);
    let request = await fetch(BASEURL+"add-grade",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            fetchStudentGrades();
            setModalShown(false)
        }
  }
  useEffect(()=>{
    fetchStudents();
    if(!user.loggedIn){
      navigate("/");
    }
    fetchStudentGrades();
  },[user.loggedIn,modalShown])
    return (
        <div className='main'>
            <h2>Student Management</h2>
            <CustomModal setModalShown={setModalShown} 
                modalShown={modalShown} 
                heading={`Edit ${studentGrades.results.length>0?studentGrades.results[selectedIndex].firstName:""}'s grade`} >
                <EditGrade setModalShown={setModalShown} grade={studentGrades.results[selectedIndex]} />
            </CustomModal>
            <form>
                <label >Student Name:
                    {/*<input type="text" id="studentName" name="studentName" />*/}</label>
                    
                    <select 
                    onChange={(e)=>{
                        let userID = e.target.value.split("-")[0];
                        setCredentials({...credentials,studentID:userID})
                        console.log(userID);
                        
                        fetchCourses(userID);
                    }}
                    >
                        {
                            data.results.length>0?
                            data.results.map((item,index)=>{
                                //@ts-ignore
                                return <option key={index} >{item.id}-{item.firstName} {item.lastName}</option>
                            }):<div></div>
                        }
                    </select>
                    <br /><br />
                
                <label >Course Name:
                    {/*<input type="text" id="studentName" name="studentName" />*/}</label>
                    
                    <select
                    onChange={(e)=>{
                        setCredentials({...credentials,courseID:e.target.value})
                    }}
                    >
                        {
                            studentCourses.results.length>0?
                            studentCourses.results.map((item,index)=>{
                                //@ts-ignore
                                return <option key={index} >{item.id}-{item.name}</option>
                            }):<div></div>
                        }
                    </select>
                    <br /><br />

                <label >Grade:
                    {/*<input type="text" id="grade" name="grade" />*/}</label>
                    <select 
                    
                    onChange={(e)=>setCredentials({...credentials,grade:e.target.value})}
                    >
                        {
                            grades.map((item,index)=>{
                                //@ts-ignore
                                return <option key={index} >{item}</option>
                            })
                        }
                    </select>    
                <br /><br />

                <label >Feedback:<br />
                    <textarea onChange={(e)=>setCredentials({...credentials,feedback:e.target.value})} id="feedback" name="feedback" rows={4} cols={50}></textarea></label><br /><br />

                <input type="submit" onClick={addGrade} value="Submit" />
            </form>

            <h2>Student Performance</h2>
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Course</th>
                        <th>Grade</th>
                        <th>Feedback</th>
                        <th>progress</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        studentGrades.results.map((item,index)=>{
                            return<tr>
                                <td>{item.firstName} {item.lastName}</td>
                                <td>{item.courseName}</td>
                                <td>{item.grade}</td>
                                <td>{item.feedback}</td>
                                <td></td>
                                <td><button onClick={()=>{
                                    setSelectedIndex(index);
                                    setModalShown(true);
                                
                                }} >Edit</button></td>
                            </tr>
                        })
                    }
                </tbody>

            </table>
        </div>
    )
}


//@ts-ignore
const EditGrade = ({setModalShown,grade})=>{
    console.log(grade);
    
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        courseID:null,
        feedback:null,
        grade:null,
        studentID:null
    });

    //@ts-ignore
    const user = useStore((store) => store.user);

  //@ts-ignore
  const handleSubmit = async (e)=>{
    e.preventDefault();
    let formData = new FormData();
    formData.append("edit-grade","edit");
    formData.append("gradeID",grade?.id);
    formData.append("courseID",grade?.courseID);
    formData.append("studentID",grade?.studentID);
    formData.append("instructorID",user.data.id);
    formData.append("grade",credentials.grade??grade?.grade);
    formData.append("feedback",credentials.feedback??grade?.feedback);
    let request = await fetch(BASEURL,
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
  }

    useEffect(()=>{
      
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Grade:
                    {/*<input type="text" id="grade" name="grade" />*/}</label>
                    <select 
                    
                    onChange={(e)=>setCredentials({...credentials,grade:e.target.value})}
                    >
                        {
                            grades.map((item,index)=>{
                                //@ts-ignore
                                return <option key={index} >{item}</option>
                            })
                        }
                    </select>    
                    <label >Feedback:
                        </label>
                    <textarea
                     placeholder={grade?.feedback}
                     onChange={e => setCredentials({...credentials,feedback:e.target.value})} 
                    id="firstName" name="firstName" />
                    <label >Select program:
                        </label>
                    
                    <button style={{display:"block"}} type="submit">Update</button>
                </form>
)
}
export default Students