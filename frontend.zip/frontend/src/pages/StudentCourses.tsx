import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router';
import { URLS } from '../utils/DataURLS';
import useStore from '../store';

const StudentCourses = () => {
    const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        error:false,
        message:""
    });
//@ts-ignore
const user = useStore((store) => store.user);

const fetchStudents = async ()=>{
    let request = await fetch(`${URLS.getStudentCourses}${user.data.id}`,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setData({error:response.error,message:response.message,results:response.data});
    console.log(response);
}

  
  useEffect(()=>{
    fetchStudents();
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
            <h2>Courses and Content</h2>

        <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Course</th>
                        <th>Content</th>
                        <th>Objectives</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        data.results.map((item,index)=>{
                            return <tr>
                                    <td>{index+1}</td>
                                    <td>{item.name}</td>
                                    <td>{item.content}</td>
                                    <td>{item.objectives}</td>
                                </tr>
                        })
                    }
                </tbody>
            </table>
    </div>
  )
}

export default StudentCourses;