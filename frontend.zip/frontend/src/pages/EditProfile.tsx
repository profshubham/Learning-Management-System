import React,{useEffect} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const EditProfile = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div>EditProfile</div>
  )
}

export default EditProfile