import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';
import CustomModal from '../components/CustomModal';
import { BASEURL, URLS } from '../utils/DataURLS';

//@ts-ignore
const roles = [
    "student",
    "admin",
    "coordinator",
    "instructor",
    "QA",
];

const Users = () => {
    const [modalShown,setModalShown] = useState(false);
    const [activeTab,setActivetab] = useState(null);
    const [selectedIndex,setSelectedIndex] = useState(0);

  //@ts-ignore
  const user = useStore((store) => store.user);
    const navigate  = useNavigate();
const [data,setData] = useState({
    results:[],
    error:false,
    message:""
});

//@ts-ignore
const handleDelete = (index)=>{
    let formData = new FormData();
    formData.append("remove-user","delete");
    //@ts-ignore
    formData.append("userID",data.results[index].id);
    fetch(BASEURL,{ 
        method:"POST",
        body:formData
    }).then(req=>req.json()).then(res=>{
        console.log(res);
        if(!res.error){
            fetchUsers();
        }
    }).catch(e=>{
        console.log(e);
    })
}

const fetchUsers = async ()=>{
    let request = await fetch(URLS.getUsers,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setData({error:response.error,message:response.message,results:response.data})
    console.log(response);
}
  useEffect(()=>{
    fetchUsers();
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn,modalShown]);

  return (
    <div className='main'>
        <h2>List of User Accounts</h2>
        <button id="popup" onClick={()=>{
            //@ts-ignore
            setActivetab(0);
            setModalShown(true)}} >Add New User Account</button>
            {/*@ts-ignore */}
        <CustomModal 
        setModalShown={setModalShown} 
        modalShown={modalShown} 
        heading={activeTab==0?"Add User":`Edit ${data?.results?.length>0?data?.results[selectedIndex]?.firstName:""}`}>
            {
                activeTab==0?
                <AddUser setModalShown={setModalShown} />:
                <EditUser 
                    user={data?.results?.length>0?data?.results[selectedIndex]:{}} 
                    rolesShown={true} 
                    setModalShown={setModalShown} />
            }
        </CustomModal>
        <div id="myModal" className="modal">
            <div className="modal-content">
                <h2>Add New User Account</h2>
                <form>
                    <label >User Name:
                    <input type="text" id="userName" name="userName" required/></label><br/><br/>

                    <label >Email:
                    <input type="email" id="userEmail" name="userEmail" required/></label><br/><br/>

                    <label>Role:
                    <select id="userRole" name="userRole" required>
                        <option value="Instructor">Instructor</option>
                        <option value="Student">Student</option>
                    </select></label><br/><br/>

                    <input type="submit" value="Add User"/>
                </form>
                <button>Close</button>
            </div>
        </div>
    <table>
        <tr>
            <th>User Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Action</th>
        </tr>
        
        {
            data?.results?.map((item,index)=>{
                return(
                    <>
                    {
                        //@ts-ignore
                        user.data.id == item.id?
                        <></>:
                        <tr>
                            {/*@ts-ignore*/}
                            <td>{item.firstName} {item.lastName}</td>
                            {/*@ts-ignore*/}
                            <td>{item.email}</td>
                            {/*@ts-ignore*/}
                            <td>{item.role}</td>
                            <td><a href="#" onClick={()=>{
                                //@ts-ignore
                                setSelectedIndex(index);
                                //@ts-ignore
                                setActivetab(1);
                                //@ts-ignore
                                setModalShown(true);

                            }} >Edit</a> | <a  
                                        onClick={()=>{
                                           
                                            //@ts-ignore
                                        handleDelete(index);
                                        }}  
                                    href="#" >Delete</a>
                            </td>
                        </tr>
                    }
                    </>
                    
                )
            })
        }
    </table>
    </div>
  )
}

//@ts-ignore
export const AddUser = ({setModalShown,rolesShown=true})=>{
    const [firstName, setFirstName] = useState("")
    const [lastName, setLastName] = useState("")
    const [role, setRole] = useState(roles[0])
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    // form fields errors
    const [firstNameError, setFirstNameError] = useState(false)
    const [lastNameError, setLastNameError] = useState(false)
    const [emailError, setEmailError] = useState(false)
    const [passwordError, setPasswordError] = useState(false)
        // error and normal field css
  const outlineError = { outline: "1px solid red" }
  const outlineNormal = { outline: "unset" }
  //@ts-ignore
  const user = useStore((store) => store.user);

  const [data,setData] = useState({
        state:false,
        message:""
    });


  //@ts-ignore
 const handleSubmit = (e) => {
    e.preventDefault()
    if (!firstName) setFirstNameError(true)
    if (!lastName) setLastNameError(true)
    if (!email) setEmailError(true)
    if (!password) setPasswordError(true)
    
    if (!firstName || !lastName || !email || !password) {
      alert("All Fields Required")
      return;
    }

else{
  let formData = new FormData();
  formData.append("register","register");
  formData.append("firstName",firstName);
  formData.append("lastName",lastName);
  formData.append("role",role);
  formData.append("email",email);
  formData.append("password",password);
  fetch(BASEURL+"register",{
      method:"POST",
      body:formData
  })
  .then(req=>req.json())
  .then(res=>{
      console.log(res);
      if(!res.error){
      setModalShown(false);
      setEmail("")
      setPassword("")
      setFirstName("")
      setLastName("")
      }else{
        setData({
                  state:true,
                  message:res.message
          })
      }
  }).catch(e=>{
      console.log(e);
  })
  
}
}

useEffect(() => {
    if (firstNameError && firstName) setFirstNameError(false)
    if (lastNameError && lastName) setLastNameError(false)
    if (emailError && email) setEmailError(false)
    if (passwordError && password) setPasswordError(false)
  }, [firstName, lastName, email, password])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >First Name:
                    <input style={firstNameError ? outlineError : outlineNormal} 
                    value={firstName} onChange={e => setFirstName(e.target.value)} type="text" 
                    id="firstName" name="firstName" /></label>
                    
                    <label >Last Name:
                        <input style={lastNameError ? outlineError : outlineNormal} value={lastName} onChange={e => setLastName(e.target.value)} type="text" id="lastName" name="lastName" /></label>
                    {
                        rolesShown?
                        <>
                            <label >Selet role:</label>
                                <select 
                                onChange={(e)=>setRole(e.target.value)}
                                style={{
                                    width:"100%"
                                }}
                                >
                                    {
                                        roles.map(item=><option>{item}</option>)
                                    }
                                </select>
                        </>:<></>
                    }
                    <label style={{ display: "block" }}>Email:
                        <input value={email} onChange={e => setEmail(e.target.value)} style={emailError ? {  display: "block", width: "100%", outline: "1px solid red"  } : {  outline: "unset" , display: "block", width: "100%" }} type="email" id="email" name="email" /></label>

                    <label >Password:
                        <input style={passwordError ? outlineError : outlineNormal} value={password} onChange={e => setPassword(e.target.value)} type="password" id="password" name="password" /></label>
                    
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

//@ts-ignore
export const EditUser = ({user,setModalShown,rolesShown=false,isEditingSelf=false})=>{
    
    //@ts-ignore
    const updateUser = useStore((store) => store.updateUser)

    const [firstName, setFirstName] = useState(user?.firstName)
    const [lastName, setLastName] = useState(user?.lastName)
    const [email, setEmail] = useState(user?.email)
    const [role, setRole] = useState(user?.role)
    // form fields errors
    const [firstNameError, setFirstNameError] = useState(false)
    const [lastNameError, setLastNameError] = useState(false)
    const [emailError, setEmailError] = useState(false)
        // error and normal field css
    const outlineError = { outline: "1px solid red" }
    const outlineNormal = { outline: "unset" }


      //@ts-ignore
 const handleSubmit = (e) => {
    e.preventDefault()
    if (!firstName) setFirstNameError(true)
    if (!lastName) setLastNameError(true)
    if (!email) setEmailError(true)
    
    if (!firstName || !lastName || !email) {
      alert("All Fields Required")
      return;
    }

else{
  let formData = new FormData();
  formData.append("edit-profile","edit-profile");
  formData.append("firstName",firstName);
  formData.append("lastName",lastName);
  formData.append("role",role??user?.role);
  
  
  formData.append("email",email);
  formData.append("userID",user?.id);
  fetch(BASEURL+"edit-user",{
      method:"POST",
      body:formData
  })
  .then(req=>req.json())
  .then(res=>{
      console.log(res);
      if(isEditingSelf){
        localStorage.removeItem("user");
        localStorage.setItem("user",JSON.stringify(res.data));
        updateUser({loggedIn:true,data:res.data});
      }
      setModalShown(false);
      setEmail("")
      setFirstName("")
      setLastName("")
  }).catch(e=>{
      console.log(e);
  })
  
}
}

useEffect(()=>{
    setFirstName(user?.firstName);
    setLastName(user?.lastName);
    setEmail(user?.email);
},[user])
    return (
        <>
            <form method="post" onSubmit={handleSubmit}>

                    <label >First Name:
                    <input 
                        style={firstNameError ? outlineError : outlineNormal} 
                        
                        value={firstName}
                        placeholder={user?.firstName} 
                        onChange={e => setFirstName(e.target.value)} 
                        type="text" id="firstName" name="firstName" /></label>

                    <label >Last Name:
                        <input style={lastNameError ? outlineError : outlineNormal} 
                        
                        value={lastName}
                        placeholder={user?.lastName} onChange={e => setLastName(e.target.value)} type="text" id="lastName" name="lastName" /></label>
                    
                    {rolesShown?<>
                    <label>Role</label>
                    <select 
                    onChange={(e)=>setRole(e.target.value)}
                    style={{
                        width:"100%"
                    }}
                    >
                        {
                            roles.map(item=>{
                                return item==user?.role?<option selected >{item}</option>:<option>{item}</option>
                            })
                        }
                    </select>
                    </>:<></>}
                    <label style={{ display: "block" }}>Email:
                        <input 
                        value={email}
                        placeholder={user?.email} onChange={e => setEmail(e.target.value)} style={emailError ? {  display: "block", width: "100%", outline: "1px solid red"  } : {  outline: "unset" , display: "block", width: "100%" }} type="email" id="email" name="email" /></label>
                    <button style={{display:"block"}} type="submit">Edit</button>
                </form>
        </>
    )
}

export default Users;