import React,{useEffect,useState} from 'react'
import ReviewModal from '../components/ReviewModal'
import { useNavigate } from 'react-router';
import useStore from '../store';
import { BASEURL, URLS } from '../utils/DataURLS';
import CustomModal from '../components/CustomModal';

const Review = () => {
  const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

      const fetchDecisions = async()=>{
    try {
        let request = await fetch(URLS.getCourseReviews,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

  //@ts-ignore
  const deleteReview = async(id)=>{
    try {
        let formData = new FormData();
        formData.append("delete-course-review","delete");
        formData.append("courseReviewID",id);
        let request = await fetch(BASEURL,
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        //@ts-ignore
        await fetchDecisions();
    } catch (error) {
        
    }
  }
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchDecisions();
  },[user.loggedIn,modalShown])
  return (
    <div>
        <h1>Program Reviews</h1>
        <button id="popup" onClick={()=>{
          setActivetab(0);
          setModalShown(true);
        }} >Add Review</button>
        <CustomModal setModalShown={setModalShown} modalShown={modalShown} heading={activeTab==0?"Add review":"Edit review"} >
                {
                    activeTab==0?
                    <AddReview setModalShown={setModalShown} />:
                    <EditReview setModalShown={setModalShown} review={data.results[selectedIndex]} />
                }
        </CustomModal>
        <h2>List of Program Reviews</h2>
        <table>
            <tr>
                <th>Review ID</th>
                <th>Date</th>
                <th>Review Title</th>
                <th>Review Details</th>
                <th>Action</th>
            </tr>
            
              {
                data.results.map((item,index)=>{
                  return <tr>
                          <td>{index+1}</td>
                          <td>{item.createdAt}</td>
                          <td>{item.title}</td>
                          <td>{item.details}</td>
                          <td><a href="#" onClick={()=>{
                            setActivetab(1);
                            setSelectedIndex(index);
                            setModalShown(true);
                          }} >Edit</a> | <a href="#" onClick={()=>{
                            deleteReview(item.id)
                          }} > Delete</a></td>
                      </tr>
                })
              }
        </table>
        <ReviewModal/>
    </div>
  )
}


//@ts-ignore
const AddReview = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [programs,setPrograms] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:null,
        details:null,
        programID:null,
        admissionInformation:null
    });
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("add-course-review","add");
        formData.append("title",credentials.title);
        formData.append("details",credentials.details);
        formData.append("courseID",credentials.programID?credentials.programID.split("-")[0]:programs.results[0].id);
        formData.append("admissionInformation",credentials.admissionInformation);
        let request = await fetch(BASEURL+"add-course-review",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
    const fetchPrograms = async()=>{
      try {
        let request = await fetch(URLS.getCourses,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setPrograms({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
    }
    useEffect(()=>{
      fetchPrograms();
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Title:
                    <input
                     onChange={e => setCredentials({...credentials,title:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Details:
                        </label>
                    <textarea onChange={e => setCredentials({...credentials,details:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>
                    <label >Select program:
                        </label>
                    <select onChange={(e)=>setCredentials({...credentials,programID:e.target.value})} >
                      {
                        programs.results.map((item,index)=>{
                          return <option key={index} >{item.id} - {item.name}</option>
                        })
                      }
                    </select>
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

//@ts-ignore
const EditReview = ({setModalShown,review})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [programs,setPrograms] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:null,
        details:null,
        programID:null,
        admissionInformation:null
    })
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("edit-course-review","edit");
        formData.append("courseReviewID",review.id);
        formData.append("courseID",credentials.programID?credentials.programID.split("-")[0]:review.courseID);
        formData.append("title",credentials.title??review?.title);
        formData.append("details",credentials.details??review?.details);
        let request = await fetch(BASEURL+"edit-course-review",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }

    const fetchPrograms = async()=>{
      try {
        let request = await fetch(URLS.getCourses,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setPrograms({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

    useEffect(()=>{
      fetchPrograms();
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Title:
                    <input
                        placeholder={review?.title}
                     onChange={e => setCredentials({...credentials,title:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Details:
                        </label>
                    <textarea
                     placeholder={review?.details}
                     onChange={e => setCredentials({...credentials,details:e.target.value})} 
                    id="firstName" name="firstName" />
                    <label >Select program:
                        </label>
                    <select onChange={(e)=>setCredentials({...credentials,programID:e.target.value})} >
                      {
                        programs.results.map((item,index)=>{
                          return <option key={index} >{item.id} - {item.name}</option>
                        })
                      }
                    </select>
                    <button style={{display:"block"}} type="submit">Update</button>
                </form>
)
}

export default Review