import React,{useEffect} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const QaReports = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div>QaReports</div>
  )
}

export default QaReports