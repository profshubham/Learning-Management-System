import React,{useEffect} from 'react'
import UserProfile from '../components/UserProfile'
import { useNavigate } from 'react-router';
import useStore from '../store';

const Instructor = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
        <UserProfile/>
    </div>
  )
}

export default Instructor