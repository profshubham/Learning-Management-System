import React,{useEffect} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const Communication = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
         <h1>Communication</h1>
        <p>Stay connected with your instructors and fellow students. Use the communication features to ask questions, participate in discussions, and collaborate on coursework.</p>
        <ul>
            <li><a href="#">Instructor Messages</a></li>
            <li><a href="#">Discussion Forums</a></li>
            <li><a href="#">Chat with Peers</a></li>
            
        </ul>

    </div>
  )
}

export default Communication