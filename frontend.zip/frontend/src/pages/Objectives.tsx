import React,{useState,useEffect} from 'react';
import { useNavigate } from 'react-router';
import useStore from '../store';
import CustomModal from '../components/CustomModal';
import { BASEURL, URLS } from '../utils/DataURLS';

const Objectives = () => {
    const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });
  //@ts-ignore
  const user = useStore((store) => store.user);

  const fetchPrograms = async()=>{
    try {
        let request = await fetch(URLS.getPrograms,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

  //@ts-ignore
  const deleteProgram = async(id)=>{
    try {
        let formData = new FormData();
        formData.append("delete-program","delete");
        formData.append("programID",id);
        let request = await fetch(BASEURL+"delete-program",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        //@ts-ignore
        await fetchPrograms();
    } catch (error) {
        
    }
  }
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }

    fetchPrograms();
  },[user.loggedIn,modalShown])
    return (
        <div className='main'>
            <button id="popup" onClick={()=>{
            //@ts-ignore
            setActivetab(0);
            setModalShown(true)}} >Add New Program</button>

            <CustomModal setModalShown={setModalShown} modalShown={modalShown} heading={activeTab==0?"Add program":"Edit Program"} >
                {
                    activeTab==0?
                    <AddProgram setModalShown={setModalShown} />:
                    <EditProgram setModalShown={setModalShown} program={data.results[selectedIndex]} />
                }
            </CustomModal>
            <h2>List of Programs and  Objectives</h2>
            <table>
                <tr>
                    <th>Objective ID</th>
                    <th>Program name</th>
                    <th>Objective Description</th>
                    <th>Action</th>
                </tr>
                {
                    data.results.map((item,index)=>{
                        return <tr>
                                <td>{index+1}</td>
                                <td>{item.programName}</td>
                                <td>{item.objectives}</td>
                                
                                <td><a href="#" onClick={()=>{
                                    setActivetab(1);
                                    setSelectedIndex(index);
                                    setModalShown(true);
                                    }} >Edit</a> | <a href="#"  
                                    onClick={()=>{
                                    deleteProgram(item.id)
                                    }}
                                    >Delete</a></td>
                            </tr>
                    })
                }
            </table>
        </div>
    )
}

//@ts-ignore
const AddProgram = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        name:"",
        highlights:"",
        objectives:"",
        admissionInformation:""
    });
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("add-program","add");
        formData.append("programName",credentials.name);
        formData.append("highlights",credentials.highlights);
        formData.append("objectives",credentials.objectives);
        formData.append("admissionInformation",credentials.admissionInformation);
        let request = await fetch(BASEURL+"add-program",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Program name:
                    <input
                     onChange={e => setCredentials({...credentials,name:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Highlights:
                        </label>
                    <textarea
                     onChange={e => setCredentials({...credentials,highlights:e.target.value})} 
                    id="firstName" name="firstName" />

                    <label >Objectives:
                    </label>
                    <textarea
                     onChange={e => setCredentials({...credentials,objectives:e.target.value})} 
                    id="firstName" name="firstName" />
                    <label >Admission information:
                    </label>
                    <textarea
                     onChange={e => setCredentials({...credentials,admissionInformation:e.target.value})} 
                    id="firstName" name="firstName" />
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

//@ts-ignore
const EditProgram = ({setModalShown,program})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        name:program?.programName,
        highlights:program?.highlights,
        objectives:program?.objectives,
        admissionInformation:program?.admissionInformation
    })
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("edit-program","edit");
        formData.append("programID",program.id);
        formData.append("programName",credentials.name.length>0?credentials.name:program.programName);
        formData.append("highlights",credentials.highlights.length>0?credentials.highlights:program.highlights);
        formData.append("objectives",credentials.objectives.length>0?credentials.objectives:program.objectives);
        formData.append("admissionInformation",credentials.admissionInformation.length>0?credentials.admissionInformation:program.admissionInformation);
        let request = await fetch(BASEURL+"edit-program",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Program name:
                    <input
                        value={credentials.name}
                        placeholder={program?.programName}
                        onChange={e => setCredentials({...credentials,name:e.target.value})}
                         type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Highlights:
                        </label>
                    <textarea
                    value={credentials.highlights}
                     placeholder={program?.highlights}
                     onChange={e => setCredentials({...credentials,highlights:e.target.value})} 
                    id="firstName" name="firstName" 
                    
                    />

                    <label >Objectives:
                    </label>
                    <textarea
                    value={credentials.objectives}
                     placeholder={program?.objectives}
                     onChange={e => setCredentials({...credentials,objectives:e.target.value})} 
                    id="firstName" name="firstName" />
                    <label >Admission information:
                    </label>
                    <textarea
                        value={credentials.admissionInformation}
                     placeholder={program?.admissionInformation}
                     onChange={e => setCredentials({...credentials,admissionInformation:e.target.value})} 
                    id="firstName" name="firstName" />
                    <button style={{display:"block"}} type="submit">Update</button>
                </form>
)
}


export default Objectives