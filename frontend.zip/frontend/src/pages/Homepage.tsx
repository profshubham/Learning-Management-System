import React from 'react'

function Homepage() {
    return (
        <div>
            <section style={{width:"100vw", borderRadius:"0"}} className="banner">
                <h1>Welcome to Our Academic Program</h1>
                <p>Empowering Future Innovators in Computer Science</p>
                <a href="https://sxb0942.uta.cloud/" target='_blank' className="cta-button">Learn More</a>
            </section>

            <section style={{width:"100vw"}} className="news-section">
                <h2>News and Updates</h2>
                <div className="featured-news">
                    <div className="news-item">
                        <img src="../static/media/featured-news.webp" alt="Featured News Image"/>
                            <h3>Important Program Changes</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tincidunt libero ac ligula
                                vulputate.</p>
                            <a href="#" className="read-more">Read More</a>
                    </div>
                </div>
                <div className="recent-news">
                    <div className="news-item">
                        <h3>Upcoming Exam Dates</h3>
                        <p>Stay updated with the latest exam schedules and important dates.</p>
                        <a href="#" className="read-more">Read More</a>
                    </div>
                    <div className="news-item">
                        <h3>New Course Offerings</h3>
                        <p>Explore our latest courses designed to enhance your learning experience.</p>
                        <a href="#" className="read-more">Read More</a>
                    </div>
                </div>
                <div className="news-categories">
                    <h3>News Categories</h3>
                    <ul>
                        <li><a href="#">Program Changes</a></li>
                        <li><a href="#">Important Dates</a></li>
                        <li><a href="#">Announcements</a></li>
                    </ul>
                </div>
                <div className="news-search">
                    <h3>Search News</h3>
                    <form>
                        <input type="text" placeholder="Search..."/>
                            <button type="submit">Search</button>
                    </form>
                </div>
                <div className="news-subscribe">
                    <h3>Subscribe to News</h3>
                    <p>Stay informed! Subscribe to receive news updates via email.</p>
                    <form>
                        <input type="email" placeholder="Your Email"/>
                            <button type="submit">Subscribe</button>
                    </form>
                </div>
            </section>

            <section className="program-overview">
                <h2>Program Overview</h2>
                <p>Our MSC in Computer Science program is designed to provide students with a comprehensive
                    understanding of computer science...</p>
                <a href="#" className="read-more">Learn More</a>
            </section>
            <section className="program-overview">
                <h2>Services</h2>
                <p>We offer a vast range of services including accademic services</p>
                <a href="#" className="read-more">Learn More</a>
            </section>

            <section className="upcoming-events">
                <h2>Upcoming Events</h2>
                <ul>
                    <li>
                        <h3>Registration Deadline</h3>
                        <p>October 15, 2023</p>
                    </li>
                    <li>
                        <h3>Midterm Exams</h3>
                        <p>November 5-10, 2023</p>
                    </li>
                    {/* <!-- Add more upcoming events as needed --> */}
                </ul>
            </section>

            <section className="quick-links">
                <h2>Quick Links</h2>
                <ul>
                    <li><a href="#">Program Objectives</a></li>
                    <li><a href="#">Courses</a></li>
                    <li><a href="#">Exams</a></li>
                    <li><a href="#">User Accounts</a></li>
                    {/* <!-- Add more quick links as needed --> */}
                </ul>
            </section>
        </div>
    )
}

export default Homepage
Homepage