import { useNavigate } from "react-router";
import useStore from "../store";
import {useEffect,useState} from "react";
import CustomModal from "../components/CustomModal";
import { BASEURL, URLS } from "../utils/DataURLS";
const Compliance = () => {
    const navigate = useNavigate();
     const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });
  //@ts-ignore
  const user = useStore((store) => store.user);

  const fetchDecisions = async()=>{
    try {
        let request = await fetch(URLS.getCompliances,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }

    fetchDecisions();
  },[user.loggedIn,modalShown])
  return (
    <div className='main'>
        <h1>Compliance records</h1>
        <button id="popup" onClick={()=>setModalShown(true)} > Add compliance</button>
        <CustomModal setModalShown={setModalShown} modalShown={modalShown} heading={"Add "} >
                    <AddReview setModalShown={setModalShown} />

        </CustomModal>
            <table>
                <tr>
                    <th>Record ID</th>
                    <th>Date</th>
                    <th>Compliance Title</th>
                    <th>Compliance Details</th>
                    <th>Action</th>
                </tr>
                {
                data.results.map((item,index)=>{
                    return <tr>
                            <td>{index+1}</td>
                            <td>{item.createdAt}</td>
                            <td>{item.title}</td>
                            <td>{item.details}</td>
                            <td><a href="#">View</a></td>
                        </tr>
                })
            }

            </table>

            <div id="myModal" className="modal">
                <div className="modal-content">
                    <h2>Add Compliance </h2>
                    <form>

                        <label >Record ID:
                            <input type="text" id="recordID" name="recordID" readOnly /></label>

                        <label >Date:
                            <input type="text" id="recordDate" name="recordDate" readOnly /></label>

                        <label >Compliance Title:
                            <input type="text" id="recordTitle" name="recordTitle" readOnly /></label>

                        <label >Compliance Details:
                            <textarea id="recordDetails" name="recordDetails" readOnly></textarea></label>

                        <input type="submit" value="Add Review" />

                    </form>
                    <button>Close</button>
                </div>

            </div>

        </div>
    )
}


//@ts-ignore
const AddReview = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [programs,setPrograms] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:null,
        details:null,
        programID:null,
        admissionInformation:null
    });
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("add-compliance","add");
        formData.append("title",credentials.title);
        formData.append("details",credentials.details);
        let request = await fetch(BASEURL+"add-compliance",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
    useEffect(()=>{
      
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Title:
                    <input
                     onChange={e => setCredentials({...credentials,title:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Details:
                        </label>
                    <textarea onChange={e => setCredentials({...credentials,details:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

export default Compliance