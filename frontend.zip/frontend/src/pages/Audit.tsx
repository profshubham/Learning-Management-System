import { useNavigate } from "react-router";
import useStore from "../store";
import {useEffect,useState} from "react";
import { BASEURL, URLS } from "../utils/DataURLS";
import CustomModal from "../components/CustomModal";

const Audit = () => {
const navigate = useNavigate();
     const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });
  //@ts-ignore
  const user = useStore((store) => store.user);

  const fetchDecisions = async()=>{
    try {
        let request = await fetch(URLS.getAudits,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }

    fetchDecisions();
  },[user.loggedIn,modalShown])
  return (
    <div className='main'>
        <h1>Audit records</h1>
        <button id="popup" onClick={()=>setModalShown(true)} > Add audit</button>
        <CustomModal setModalShown={setModalShown} modalShown={modalShown} heading={"Add "} >
                    <AddReview setModalShown={setModalShown} />
        </CustomModal>
        <h2>List of Audits</h2>
        <table>
            <tr>
                <th>Audit ID</th>
                <th>Date</th>
                <th>Course Name</th>
                <th>Audit Details</th>
                <th>Action</th>
            </tr>
            {
                data.results.map((item,index)=>{
                    return <tr>
                            <td>{index+1}</td>
                            <td>{item.createdAt}</td>
                            <td>{item.name}</td>
                            <td>{item.details}</td>
                            <td><a href="#">View</a></td>
                        </tr>
                })
            }

        </table>
        <div id="myModal" className="modal">
            <div className="modal-content">
                <h2>audit form</h2>
                <form>
                    <label >Audit ID:
                    <input type="text" id="auditID" name="auditID" readOnly/></label>

                    <label >Date:
                    <input type="text" id="auditDate" name="auditDate" readOnly/></label>

                    <label >Course Name:
                    <input type="text" id="courseName" name="courseName" readOnly/></label>

                    <label >Audit Details:
                    <textarea id="auditDetails" name="auditDetails" readOnly></textarea></label>

                    <input type="submit" value="Add Review"/>


                </form>
                <button >Close</button>



            </div>
        </div>
    </div>
  )
}

//@ts-ignore
const AddReview = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [courses,setCourses] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:null,
        details:null,
        courseID:null,
        admissionInformation:null
    });
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("add-audit","add");
        formData.append("title",credentials.title);
        formData.append("details",credentials.details);
        formData.append("courseID",credentials.courseID?credentials.courseID.split("-")[0]:courses.results[0].id);
        let request = await fetch(BASEURL+"add-audit",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
    const fetchCourses = async()=>{
      try {
        let request = await fetch(URLS.getCourses,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setCourses({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
    }
    useEffect(()=>{
      fetchCourses();
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Title:
                    <input
                     onChange={e => setCredentials({...credentials,title:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Details:
                        </label>
                    <textarea onChange={e => setCredentials({...credentials,details:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>
                    <label >Select course:
                        </label>
                    <select onChange={(e)=>setCredentials({...credentials,courseID:e.target.value})} >
                      {
                        courses.results.map((item,index)=>{
                          return <option key={index} >{item.id} - {item.name}</option>
                        })
                      }
                    </select>
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

export default Audit