import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';
import { BASEURL, URLS } from '../utils/DataURLS';
import CustomModal from '../components/CustomModal';
import { AddUser, EditUser } from './Users';

const StudentsContact = () => {
  const [selectedIndex,setSelectedIndex] = useState(0);
  const [modalShown,setModalShown] = useState(false);
  const [activeTab,setActivetab] = useState(0);
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  const [data,setData] = useState({
        results:[],
        error:false,
        message:""
    });
    const fetchUsers = async ()=>{
    let request = await fetch(URLS.getStudents,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setData({error:response.error,message:response.message,results:response.data})
    console.log(response);
}

//@ts-ignore
const handleDelete = (index)=>{
    let formData = new FormData();
    formData.append("remove-user","delete");
    //@ts-ignore
    formData.append("userID",data.results[index].id);
    fetch(BASEURL,{ 
        method:"POST",
        body:formData
    }).then(req=>req.json()).then(res=>{
        console.log(res);
        if(!res.error){
            fetchUsers();
        }
    }).catch(e=>{
        console.log(e);
    })
}
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchUsers();
  },[user.loggedIn])
  return (
    <div className='main'>
         <h1>Contact Students</h1>
        <button id="popup" onClick={()=>{
            setActivetab(0);
            setModalShown(true);
            }} >Add </button>
        <CustomModal setModalShown={setModalShown} modalShown={modalShown} >
            {
                activeTab==0?
                <AddUser setModalShown={setModalShown} />:
                <EditUser user={data?.results[selectedIndex]} setModalShown={setModalShown}/>
            }
        </CustomModal>
        <h2>List of Students</h2>
        <table>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>

            {
            data?.results?.map((item,index)=>{
                return(
                    <>
                    {
                        //@ts-ignore
                        user.data.id == item.id?
                        <></>:
                        <tr>
                            {/*@ts-ignore*/}
                            <td>{index+1}</td>
                            {/*@ts-ignore*/}
                            <td>{item.firstName} {item.lastName}</td>
                            {/*@ts-ignore*/}
                            <td>{item.email}</td>
                            <td><a href="#" onClick={()=>{
                                //@ts-ignore
                                setSelectedIndex(index);
                                //@ts-ignore
                                setActivetab(1);
                                //@ts-ignore
                                setModalShown(true);

                            }} >Edit</a> | <a  
                                        onClick={()=>{
                                           
                                            //@ts-ignore
                                        handleDelete(index);
                                        }}  
                                    href="#" >Delete</a>
                            </td>
                        </tr>
                    }
                    </>
                    
                )
            })
        }
        </table>
    </div>
  )
}

export default StudentsContact