import React,{useEffect, useState} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';
import { BASEURL, URLS } from '../utils/DataURLS';
import CustomModal from '../components/CustomModal';

const Courses = () => {
const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

      const fetchCourses = async()=>{
    try {
        let request = await fetch(URLS.getCourses,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

  //@ts-ignore
  const deleteCourse = async(id)=>{
    try {
        let formData = new FormData();
        formData.append("delete-course","delete");
        formData.append("courseID",id);
        let request = await fetch(BASEURL+"delete-course",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        //@ts-ignore
        await fetchCourses();
    } catch (error) {
        
    }
  }
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchCourses();
  },[user.loggedIn,modalShown])
    return (
        <div className='main'>
            <h2>Courses and Content</h2>
            <button id="add-course-button" onClick={()=>{
                                        //@ts-ignore
                                        setActivetab(0);
                                        setModalShown(true);

                                    }} >Add Course</button>

            <CustomModal setModalShown={setModalShown} modalShown={modalShown} heading={activeTab==0?"Add course":"Edit course"} >
                {
                    activeTab==0?
                    <AddCourse setModalShown={setModalShown} />:
                    <EditCourse setModalShown={setModalShown} course={data.results[selectedIndex]} />
                }
            </CustomModal>
            

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Course</th>
                        <th>Content</th>
                        <th>Objectives</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        data.results.map((item,index)=>{
                            return <tr>
                                    <td>{index+1}</td>
                                    <td>{item.name}</td>
                                    <td>{item.content}</td>
                                    <td>{item.objectives}</td>
                                    <td><button
                                    onClick={()=>{
                                        //@ts-ignore
                                        setActivetab(1);
                                        setSelectedIndex(index);
                                        setModalShown(true);

                                    }}
                                    className="edit-button">Edit</button><button 
                                    style={{
                                        marginLeft:10
                                    }}

                                    onClick={()=>{
                                        deleteCourse(item.id)
                                    }}
                                    >Delete</button></td>
                                </tr>
                        })
                    }
                </tbody>
            </table>
        </div>

  )
}



//@ts-ignore
const AddCourse = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [programs,setPrograms] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        name:null,
        content:null,
        programID:null,
        objectives:null
    });
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("add-course","add");
        formData.append("name",credentials.name);
        formData.append("content",credentials.content);
        formData.append("programID",credentials.programID?credentials.programID.split("-")[0]:programs.results[0].id);
        formData.append("objectives",credentials.objectives);
        let request = await fetch(BASEURL+"add-course",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
    const fetchPrograms = async()=>{
      try {
        let request = await fetch(URLS.getPrograms,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setPrograms({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
    }
    useEffect(()=>{
      fetchPrograms();
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >name:
                    <input
                     onChange={e => setCredentials({...credentials,name:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    
                    <label >Select program:
                        </label>
                    <select onChange={(e)=>setCredentials({...credentials,programID:e.target.value})} >
                      {
                        programs.results.map((item,index)=>{
                          return <option key={index} >{item.id} - {item.programName}</option>
                        })
                      }
                    </select>
                    <label >content:
                        </label>
                    <textarea onChange={e => setCredentials({...credentials,content:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>

                    <label >objectives:
                        </label>
                    <textarea onChange={e => setCredentials({...credentials,objectives:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>
                    
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

//@ts-ignore
const EditCourse = ({setModalShown,course})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [programs,setPrograms] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        name:null,
        content:null,
        programID:null,
        objectives:null
    })
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("edit-course","edit");
        formData.append("courseID",course?.id);
        formData.append("programID",credentials.programID?credentials.programID.split("-")[0]:course.programID);
        formData.append("name",credentials.name??course?.name);
        formData.append("content",credentials.content??course?.content);
        formData.append("objectives",credentials.objectives??course?.objectives);
        let request = await fetch(BASEURL+"edit-course",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }

    const fetchPrograms = async()=>{
      try {
        let request = await fetch(URLS.getPrograms,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setPrograms({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

    useEffect(()=>{
      fetchPrograms();
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >name:
                    <input
                        placeholder={course?.name}
                     onChange={e => setCredentials({...credentials,name:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>

                    <label >Select program:
                        </label>
                    <select onChange={(e)=>setCredentials({...credentials,programID:e.target.value})} >
                      {
                        programs.results.map((item,index)=>{
                          return <option key={index} >{item.id} - {item.programName}</option>
                        })
                      }
                    </select>
                    <label >content:
                        </label>
                    <textarea
                     placeholder={course?.content}
                     onChange={e => setCredentials({...credentials,content:e.target.value})} 
                    id="firstName" name="firstName" />
                    

                    <label >objectives:
                        </label>
                    <textarea 
                    placeholder={course?.objectives}
                    onChange={e => setCredentials({...credentials,objectives:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>
                    
                    <button style={{display:"block"}} type="submit">Update</button>
                </form>
)
}

export default Courses