
const ContactUs = () => {
    return (
        <div style={{ overflowX:"hidden"}} className="" >
            <section  style={{flexDirection:"row", width:"100%", justifyContent:"center", alignItems:"center"}} className="contact-section">
                <div className="contact-section-top">
                    <h1>Contact Us</h1>
                    <p>Feel free to get in touch with us using the contact information below.</p>
                    <ul>
                        <li>Email: info@msg.com</li>
                        <li>Phone: +123 456 7890</li>
                        <li>Address: 123 Street Name, City, Country</li>
                    </ul>
                </div>
                <form>
                    <h2>Contact Form</h2>
                    <label >Name:
                        <input type="text" id="name" name="name" required /></label>

                    <label >ID:
                        <input type="text" id="id" name="id" required /></label>

                    <label >Concern:
                        <textarea id="concern" name="concern" rows={4} required></textarea></label>
                    <button type="submit">Submit</button>
                </form>

            </section>
            <div className="social">
                <a href="#" className="facebook"><i className="fa fa-facebook"></i></a>
                <a href="#" className="twitter"><i className="fa fa-twitter"></i></a>
                <a href="#" className="instagram"><i className="fa fa-instagram"></i></a>
                <a href="#" className="whatsapp"><i className="fa fa-whatsapp"></i></a>
                <a href="#" className="pinterest"><i className="fa fa-pinterest"></i></a>
                <a href="#" className="linkedin"><i className="fa fa-linkedin"></i></a>
            </div>
        </div>
    )
}

export default ContactUs