import React,{useEffect} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const Exams = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
      <h1>Exams</h1>
        <p>Access information about upcoming exams, exam schedules, and study materials related to exams. Prepare for your assessments and measure your performance.</p>
        <ul>
            <li><a href="#">Exam 1 - Introduction to Computer Science</a></li>
            <li><a href="#">Exam 2 - Data Structures and Algorithms</a></li>
            <li><a href="#">Exam 3 - Web Development</a></li>
           
        </ul>
    </div>
  )
}

export default Exams