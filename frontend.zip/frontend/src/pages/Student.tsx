import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';
import CustomModal from '../components/CustomModal';
import { EditUser } from './Users';
import { BASEURL, URLS } from '../utils/DataURLS';

const grades = ["A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"];
const Student = () => {
    const[modalShown,setModalShown] = useState(false);
    const [activeTab,setActivetab] = useState(0);
    const navigate = useNavigate();
    
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });
//@ts-ignore
  const user = useStore((store) => store.user);
      const fetchDecisions = async()=>{
    try {
        let request = await fetch(`${URLS.getStudentCourses}${user.data.id}`,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

      const [grades,setGrades] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });
     const fetchGrades = async()=>{
      try {
        let request = await fetch(`${URLS.getStudentCoursesAnalysis}${user.data.id}`,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setGrades({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
    }

  
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchDecisions();
    fetchGrades();
  },[user.loggedIn,modalShown])
  return (
    <div className='main'>
        <header>
            <h1>Student Profile</h1>
        </header>

        <CustomModal setModalShown={setModalShown} modalShown={modalShown} >
            {
                activeTab==0?
                <EditUser 
                setModalShown={setModalShown} 
                user={user.data} 
                isEditingSelf={true} rolesShown={false} />:
                <AddCourse setModalShown={setModalShown} />
            }
        </CustomModal>

        <section id="student-details">
            <h2>Student Details</h2>
            <ul>
                <li><strong>Name:</strong> {user.data.firstName} {user.data.lastName}</li>
                <li><strong>Student ID:</strong> {user.data.id}</li>
                <li><strong>Program:</strong> MSC Computer Science</li>
                <li><strong>Email:</strong> {user.data.email}</li>
                <li><strong>Action:</strong> <a href="#" onClick={()=>{
                    setActivetab(0);
                    setModalShown(true)}} id="edit-profile">Edit Profile</a></li>
            </ul>
        </section>
 

        <section id="courses-enrolled">
            <h2>Courses Enrolled</h2>
            <button id="popup" onClick={()=>{
          setActivetab(1);
          setModalShown(true);
        }} >Add course</button>

            <ul>
                {
                    data.results.map((item,index)=>{
                        return <li><a href="#">{index+1}. {item.name}</a></li>
                    })
                }

            </ul>
        </section>

        <section id="grades">
            <h2>Grades</h2>
            <table>
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Grade</th>
                        <th>Feedback</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        grades.results.map((item,index)=>{
                            return <tr>
                                    <td>{item.name}</td>
                                    <td>{item.grade}</td>
                                    <td>{item.feedback}</td>
                                </tr>
                        })
                    }

                </tbody>
            </table>
        </section>
    </div>
  )
}


//@ts-ignore
const AddCourse = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [courses,setCourses] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:null,
        details:null,
        courseID:null,
        admissionInformation:null
    });
    //@ts-ignore
  const user = useStore((store) => store.user);
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("enroll-course","add");
        formData.append("studentID",user.data.id);
        formData.append("courseID",credentials.courseID?credentials.courseID.split("-")[0]:courses.results[0].id);
        let request = await fetch(BASEURL+"enroll-course",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
    const fetchCourses = async()=>{
      try {
        let request = await fetch(URLS.getCourses,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setCourses({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
    }


    useEffect(()=>{
      fetchCourses();
    },[])
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Select course:
                        </label>
                    <select onChange={(e)=>setCredentials({...credentials,courseID:e.target.value})} >
                      {
                        courses.results.map((item,index)=>{
                          return <option key={index} >{item.id} - {item.name}</option>
                        })
                      }
                    </select>
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

export default Student