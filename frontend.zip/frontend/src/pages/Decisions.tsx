import { useNavigate } from "react-router";
import useStore from "../store";
import {useEffect,useState} from "react";
import CustomModal from "../components/CustomModal";
import { BASEURL, URLS } from "../utils/DataURLS";


const Decisions = () => {
    const [modalShown,setModalShown] = useState(false);
    const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

      const fetchDecisions = async()=>{
    try {
        let request = await fetch(URLS.getDecisions,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }

  //@ts-ignore
  const deleteDecision = async(id)=>{
    try {
        let formData = new FormData();
        formData.append("delete-decision","delete");
        formData.append("decisionID",id);
        let request = await fetch(BASEURL+"delete-decision",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        //@ts-ignore
        await fetchDecisions();
    } catch (error) {
        
    }
  }
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchDecisions();
  },[user.loggedIn,modalShown])
    return (
        <div className='main'>
            <h1>Strategic Decisions</h1>
            <button id="popup" onClick={()=>{
                setActivetab(0);
                setModalShown(true);
            }} >Add Decision</button>
            <CustomModal setModalShown={setModalShown} modalShown={modalShown} heading={activeTab==0?"Add Decision":"Edit Program"} >
                {
                    activeTab==0?
                    <AddDecision setModalShown={setModalShown} />:
                    <EditDecision setModalShown={setModalShown} decision={data.results[selectedIndex]} />
                }
            </CustomModal>
            <h2>List of Decisions</h2>
            <table>
                <tr>
                    <th>Decision ID</th>
                    <th>Date</th>
                    <th>Decision Title</th>
                    <th>Decision Details</th>
                    <th>Action</th>
                </tr>
                {
                    data.results.map((item,index)=>{
                        return <tr>
                                <td>{index+1}</td>
                                <td>{item.createdAt}</td>
                                <td>{item.title}</td>
                                <td>{item.details}</td>
                                <td><a onClick={()=>{
                                    setActivetab(1);
                                    setSelectedIndex(index);
                                    setModalShown(true)
                                }} href="#">Edit</a> | <a onClick={()=>deleteDecision(item.id)} href="#">Delete</a></td>
                            </tr>
                    })
                }
            </table>

        </div>
    )
}


//@ts-ignore
const AddDecision = ({setModalShown})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:"",
        details:"",
        objectives:"",
        admissionInformation:""
    });
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("add-decision","add");
        formData.append("title",credentials.title);
        formData.append("details",credentials.details);
        formData.append("objectives",credentials.objectives);
        formData.append("admissionInformation",credentials.admissionInformation);
        let request = await fetch(BASEURL+"add-decision",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Title:
                    <input
                     onChange={e => setCredentials({...credentials,title:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Details:
                        </label>
                    <textarea onChange={e => setCredentials({...credentials,details:e.target.value})} 
                    id="firstName" name="firstName" ></textarea>
                    <button style={{display:"block"}} type="submit">Add</button>
                </form>
)
}

//@ts-ignore
const EditDecision = ({setModalShown,decision})=>{
    const [data,setData] = useState({
        state:false,
        message:""
    });

    const [credentials,setCredentials] = useState({
        title:null,
        details:null,
        objectives:null,
        admissionInformation:null
    })
    //@ts-ignore
    const handleSubmit = async (e)=>{
        e.preventDefault();

        let formData = new FormData();
        formData.append("edit-decision","edit");
        formData.append("decisionID",decision.id);
        formData.append("title",credentials.title??decision?.title);
        formData.append("details",credentials.details??decision?.details);
        let request = await fetch(BASEURL+"edit-decision",
            {method:"POST",
            body:formData
        });
        let response = await request.json();
        if(!response.error){
            setModalShown(false)
        }
    }
return(
    <form method="post" onSubmit={handleSubmit}>
                    {data.state?
                    <h4 style={{color:"red"}} >{data.message}</h4>:
                    <></>
                }
                    <label >Title:
                    <input
                        placeholder={decision?.title}
                     onChange={e => setCredentials({...credentials,title:e.target.value})} type="text" 
                    id="firstName" name="firstName" /></label>
                    <label >Details:
                        </label>
                    <textarea
                     placeholder={decision?.details}
                     onChange={e => setCredentials({...credentials,details:e.target.value})} 
                    id="firstName" name="firstName" />
                    <button style={{display:"block"}} type="submit">Update</button>
                </form>
)
}

export default Decisions