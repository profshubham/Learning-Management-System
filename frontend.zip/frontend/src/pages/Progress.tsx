import {
  BarElement, Chart, CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'
import { Bar } from 'react-chartjs-2'
import { useNavigate } from 'react-router'
import useStore from '../store';
import {useEffect,useState} from "react";
import { URLS } from '../utils/DataURLS';

const Progress = () => {
  const data = {
    labels: ['Course 1', 'Course 2', 'Course 3', 'Course 4'],
    datasets: [{
      label: 'Average Performance',
      data: [85, 78, 92, 88],
      backgroundColor: 'rgba(75, 192, 192, 0.6)',
      borderColor: 'rgba(75, 192, 192, 1)',
      borderWidth: 1
    }]
  }
  const options = {
    scales: {
      y: {
        beginAtZero: true,
        max: 12
      }
    }
  }
  Chart.register(BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend,);
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);

  
   const [grades,setGrades] = useState({
        results:{values:[],labels:[]},
        loading:false,
        erro:false,
        message:""
    });
     const fetchGrades = async()=>{
      try {
        let request = await fetch(`${URLS.getCoursesAnalysis}`,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setGrades({error:response.error,message:response.message,results:response.data});
        

    } catch (error) {
        
    }
    }
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchGrades();
  },[user.loggedIn])
  return (
    <div className='main'>
      <h1>Student Progress</h1>
      <Bar options={options} data={{
              labels: grades.results.labels,
              datasets: [{
                label: 'Average Performance',
                data: grades.results.values,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
              }]
            }} />
    </div>
  )
}

export default Progress