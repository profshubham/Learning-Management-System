import React,{useEffect} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const Results = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
      <h1>Exam Results</h1>
        <p>Check your exam results and performance in various assessments. You can track your progress and view detailed feedback provided by instructors.</p>
        <ul>
            <li><a href="#">Exam 1 - Introduction to Computer Science</a></li>
            <li><a href="#">Exam 2 - Data Structures and Algorithms</a></li>
            <li><a href="#">Exam 3 - Web Development</a></li>
        </ul>
    </div>
  )
}

export default Results