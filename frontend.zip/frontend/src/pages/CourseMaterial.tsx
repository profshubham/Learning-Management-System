import { useNavigate } from "react-router";
import useStore from "../store";
import {useEffect,useState} from "react";
import { URLS } from "../utils/DataURLS";
import { Link } from "react-router-dom";

const CourseMaterial = () => {
  const [selectedIndex,setSelectedIndex] = useState(0);
    const [activeTab,setActivetab] = useState(0);
    const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });

      //@ts-ignore
  const user = useStore((store) => store.user);

    const fetchCourses = async()=>{
    try {
        let request = await fetch(URLS.getCourses,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setData({error:response.error,message:response.message,results:response.data})
    } catch (error) {
        
    }
  }
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchCourses();
  },[user.loggedIn])
  return (
    <div className='main'>
      <h1>Course Materials</h1>
      <p>Access course materials, including lecture notes, textbooks, and additional resources to support your learning.</p>
      <ul>

        {
                        data.results.map((item,index)=>{
                            return <li>
                                    <Link to={`/materials/${item.id}`} >{item.name} Materials</Link>
                                </li>
                        })
                    }

      </ul>
    </div>
  )
}

export default CourseMaterial