import React,{useEffect} from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const Settings = () => {
    const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
    return (
        <div className='main'>
            <header>
                <h1>Website Settings</h1>
            </header>
            <section>
                <button id="popup" >General settings</button>
                <div id="myModal" className="modal">
                    <div className="modal-content">
                        <h2>General Settings</h2>
                        <form>
                            <label >Website Name:
                                <input type="text" id="websiteName" name="websiteName" required /></label><br /><br />

                            <label >Website Description:
                                <textarea id="websiteDescription" name="websiteDescription" rows={4}
                                    required></textarea></label><br /><br />



                            <input type="submit" value="Save Settings" />
                        </form>
                        <button >Close</button>
                    </div>
                </div>
            </section>

            <section>
                <h2>Reports and Analytics</h2>
                <p>Generate reports and analytics on program performance:</p>
                <button id="generateReports">Generate Reports</button>

            </section>

            <section>
                <h2>Design and Layout Settings</h2>
                <form>
                    <label >Background Color:
                        <input type="color" id="backgroundColor" name="backgroundColor" /></label><br /><br />

                    <label >Text Color:
                        <input type="color" id="textColor" name="textColor" /></label><br /><br />



                    <input type="submit" value="Save Design Settings" />
                </form>
            </section>
        </div>
    )
}

export default Settings