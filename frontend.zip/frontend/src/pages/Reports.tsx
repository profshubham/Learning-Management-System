import {
  BarElement, Chart, CategoryScale,
  LinearScale,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'
import { Bar } from 'react-chartjs-2'
import { useNavigate } from 'react-router'
import useStore from '../store';
import {useEffect,useState} from "react";
import { URLS } from '../utils/DataURLS';

const gradesMappings = ["A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"];

const Reports = () => {
  const [graphData,setGraphData] = useState({
    labels:[],
    values:[]
  })
  const data = {
    labels: ['Course 1', 'Course 2', 'Course 3', 'Course 4'],
    datasets: [{
      label: 'Average Performance',
      data: [85, 78, 92, 88],
      backgroundColor: 'rgba(75, 192, 192, 0.6)',
      borderColor: 'rgba(75, 192, 192, 1)',
      borderWidth: 1
    }]
  }


  const options = {
    scales: {
      y: {
        beginAtZero: true,
        max: 12
      }
    }
  }


   const [grades,setGrades] = useState({
        results:[],
        loading:false,
        erro:false,
        message:""
    });
     const fetchGrades = async()=>{
      try {
        let request = await fetch(`${URLS.getStudentCoursesAnalysis}${user.data.id}`,{method:"GET"});
        let response = await request.json();
        //@ts-ignore
        setGrades({error:response.error,message:response.message,results:response.data});
        let labels = [];
        let values = [];
        response.data.map((item,index)=>{
          //create labels
          labels.push(item.name);
          //create data

          for (let i = 0; i < gradesMappings.length; i++) {
            if(gradesMappings[i]==item.grade){
              values.push(gradesMappings.length-i);
              break;
            }
            
          }
        });

        setGraphData({labels,values});

        console.log(labels,values);
        

    } catch (error) {
        
    }
    }

  Chart.register(BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend,);


  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
    fetchGrades();
  },[user.loggedIn])
  return (
    <div className='main'>
      <h1>Reporting and Analytics</h1>
      <Bar options={options} data={{
                    labels: graphData.labels,
                    datasets: [{
                      label: 'Average Performance',
                      data: graphData.values,
                      backgroundColor: 'rgba(75, 192, 192, 0.6)',
                      borderColor: 'rgba(75, 192, 192, 1)',
                      borderWidth: 1
                    }]
                  }} />
    </div>
  )
}

export default Reports