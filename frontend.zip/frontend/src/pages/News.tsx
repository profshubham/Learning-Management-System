import React from 'react'

const News = () => {
  return (
    <div className='main'>
        <h1>Latest news</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias suscipit, quae explicabo iusto accusantium, repellat possimus voluptas quo, cum quibusdam asperiores aliquid autem quasi porro harum officia fugiat qui eveniet!</p>
    </div>
  )
}

export default News