import React,{useEffect} from 'react';
import { useNavigate } from 'react-router';
import useStore from '../store';

const Processes = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn]);
  return (
    <div className='main'>
      <h1>QA Processes</h1>
        <p>As the Quality Assurance Officer, you are responsible for implementing and maintaining quality assurance processes and policies. These processes ensure the quality and effectiveness of the academic program. Here are some key processes:</p>

        <h2>1. Course Content Validation</h2>
        <p>Review and validate course content to ensure alignment with program objectives and industry standards. Collaborate with instructors to make necessary updates.</p>

        <h2>2. Course Audits</h2>
        <p>Conduct audits of courses to identify areas for improvement. Ensure that course materials and assessments meet quality standards.</p>

        <h2>3. Recommendations</h2>
        <p>Provide recommendations for enhancing teaching methods, assessments, and overall program effectiveness based on audit findings.</p>

        <h2>4. Compliance</h2>
        <p>Ensure compliance with accreditation and regulatory requirements. Keep the program in line with educational best practices and industry trends.</p>
        
    </div>
  )
}

export default Processes