import React, { useEffect } from 'react'
import { useNavigate } from 'react-router';
import useStore from '../store';

const Programs = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
        <section id="program-introduction">
                <h1>Welcome to Our MSC Computer Science Program</h1>
                <p>Our MSC Computer Science program offers a comprehensive and cutting-edge curriculum designed to
                    prepare students for success in the field of computer science. Whether you are a recent graduate or
                    a seasoned professional, our program provides the knowledge and skills you need to excel.</p>
            </section>

            <section id="curriculum-highlights">
                <h2>Curriculum Highlights</h2>
                <ul>
                    <li>Advanced courses in artificial intelligence and machine learning.</li>
                    <li>Hands-on experience with the latest software development tools.</li>
                    <li>Opportunities for research and collaboration with industry experts.</li>
                    <li>Flexible scheduling options to accommodate working professionals.</li>
                </ul>
            </section>

            <section id="admission-information">
                <h2>Admission Information</h2>
                <p>If you're interested in joining our program, please review the admission requirements and application
                    process below:</p>
                <ul>
                    <li>A bachelor's degree in a related field.</li>
                    <li>Minimum GPA of 3.0.</li>
                    <li>Letters of recommendation.</li>
                    <li>Statement of purpose.</li>
                </ul>
                <p>To apply, complete the online application form, submit academic transcripts and required documents,
                    request letters of recommendation, write a statement of purpose, pay the application fee, and wait
                    for the admission decision.</p>
            </section>
    </div>
  )
}

export default Programs