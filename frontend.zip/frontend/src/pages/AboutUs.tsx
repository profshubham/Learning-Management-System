

const AboutUs = () => {
    return (
        <div className="main">
            <div className="about-us">
                <div className="about-us-msg-technology">
                    <div className="about-us-container">
                        <div className="about-us-item-pdlr" style={{display:"flex", flexDirection:"column", justifyContent:"start", alignItems:"start"}}>
                            <div className="about-us-page-caption">Know Us Better</div>
                            <h1 style={{color:"#db2222"}} className="about-us-page-title">About MSG Technology</h1>
                        </div>
                    </div>
                </div>

                <div className="about-us msg-technology">
                    <h1 className="about-us-title">About MSG Technology</h1>
                    <p className="about-us-text">MSG Technology is a public university . MSG Technology offers graduate in
                        Engineering, Information Technology, Computer Science.</p>
                    <p className="about-us-text">MSG Technology is committed to providing high quality education and training,
                        producing competent graduates and endeavors to excel in areas of Teaching, Training, Learning,
                        Research and Innovation, Extension and Consultancy Services to achieve its mandate.</p>
                    <p className="about-us-text">MSG Technology is ISO 9001:2015 and ISO/IEC 27001:2013 certified.</p>

                    <div className="about-us-image">
                        <img src="https://www.mut.ac.ke/wp-content/uploads/2023/06/IMG_9874-300x200.jpg" />
                    </div>

                    <div className="about-us-philosophy">
                        <h3 className="about-us-philosophy-title">Our Philosophy</h3>
                        <p className="about-us-philosophy-text">MSG Technology is committed to knowledge creation and
                            advancement through innovative strategies and technologies for prosperity.</p>
                    </div>

                    <div className="about-us-mission">
                        <h3 className="about-us-mission-title">Our Mission</h3>
                        <p className="about-us-mission-text">To advance knowledge and technological transfer through teaching,
                            training, learning, research, innovation, consultancy and community engagement for sustainable
                            development.</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AboutUs