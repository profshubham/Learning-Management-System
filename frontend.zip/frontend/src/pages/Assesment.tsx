import {useEffect} from "react";
import { useNavigate } from "react-router";
import useStore from "../store";

const Assesment = () => {
    const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
        <h2>Assessments</h2>
        <table>
            <tr>
                <th>Course</th>
                <th>Exam/Assessment</th>
                <th>Performance Indicators</th>
            </tr>
            <tr>
                <td>Course 1</td>
                <td>Midterm Exam</td>
                <td>Indicators 1</td>
            </tr>
            <tr>
                <td>Course 2</td>
                <td>Final Exam</td>
                <td>Indicators 2</td>
            </tr>
        </table>
    </div>
  )
}

export default Assesment