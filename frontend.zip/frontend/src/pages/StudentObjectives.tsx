import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router';
import { URLS } from '../utils/DataURLS';
import useStore from '../store';

const StudentObjectives = () => {
       const navigate = useNavigate();
    const [data,setData] = useState({
        results:[],
        error:false,
        message:""
    });
//@ts-ignore
const user = useStore((store) => store.user);

const fecthProgram = async ()=>{
    let request = await fetch(`${URLS.getStudentProgram}${user.data.id}`,{method:"GET"});
    let response = await request.json();
    //@ts-ignore
    setData({error:response.error,message:response.message,results:response.data});
    console.log(response);
}

  
  useEffect(()=>{
    
    if(!user.loggedIn){
      navigate("/");
    }
    fecthProgram();
  },[user.loggedIn])
  return (
    <div className='main' >Program Objectives</div>
  )
}

export default StudentObjectives;