import React,{useState} from 'react'
import { Link, useNavigate } from 'react-router-dom'
import useStore from '../store'
import { BASEURL } from '../utils/DataURLS'

const ForgotPwd = () => {
    const navigation = useNavigate()
    const updateLoginHidden = useStore(state => state.updateLoginHidden)
    const [email,setEmail] = useState("");
    const [error,setError] = useState({
        state:false,
        message:""
    });
    //@ts-ignore
    const handleSubmit = (e)=>{
        setError({state:false,message:""});
        e.preventDefault();
        let formData = new FormData();
        formData.append("forgot-password","");
        formData.append("email",email);
        fetch(BASEURL+"forgot-password",{
            method:"POST",
            body:formData
        }).then(req=>req.json())
        .then(res=>{
            console.log(res);
            setError({state:res.error,message:res.message});
        })
        .catch(e=>{
            console.log(e);
        })
    }
    return (
        <div style={{width:"40rem", height:"100%"}} className='main' >
            <h2>Forgot Password</h2>
            <h2 style={{
                color:error.state?"red":"green"
            }} >{error.message}</h2>
            <form onSubmit={handleSubmit} >
                <label >Email:
                    <input onChange={(e)=>setEmail(e.target.value)} style={{display:"block"}} type="email" id="email" name="email" placeholder="Enter your email" required /></label>
                <button onClick={() => {
                    navigation(-1)
                    updateLoginHidden(false)
                }} style={{ cursor:"pointer" , margin:".6rem", background:"unset", border:"1px solid black", color:"black"}}>Login</button>
                <button type="submit">Reset Password</button>
            </form>
        </div>
    )
}

export default ForgotPwd