import React from 'react'
import Profile from '../components/UserProfile'
import { useNavigate } from 'react-router';
import useStore from '../store';
import {useEffect} from "react";

const Coordinator = () => {
  const navigate = useNavigate();
  //@ts-ignore
  const user = useStore((store) => store.user);
  useEffect(()=>{
    if(!user.loggedIn){
      navigate("/");
    }
  },[user.loggedIn])
  return (
    <div className='main'>
        <Profile/>
        <section id="responsibilities">
        <h2>Responsibilities</h2>
        <ul>
            <li>Ensure program objectives align with institutional goals.</li>
            <li>Collaborate with instructors on course content and objectives.</li>
            <li>Conduct regular program reviews for improvement.</li>
            <li>Coordinate with administrators and stakeholders.</li>
            <li>Monitor student performance and provide support.</li>
            <li>Address student concerns and inquiries.</li>
            <li>Participate in strategic decisions for program development.</li>
        </ul>
    </section>
        
    </div>
  )
}

export default Coordinator