import { create } from 'zustand'

type User = {
  loggedIn:boolean,
  data:any
}

const useStore = create((set) => ({
  user: {},
  loginHidden:true,
  registerHidden:true,
  forgotPwdHidden:false,
  chatOpen:false,
  updateUser: (newUser: User) => set({
    user: newUser
  }),

  removeUser: () => set(()=>({ user: {} })),

  updateLoginHidden:(value=>set(store=>({loginHidden:value}))),
  updateRegisterHidden:(value=>set(store=>({registerHidden:value}))),
  updateForgotPwdHidden:(value=>set(store=>({forgotPwdHidden:value}))),
  updateChat:(value=>set(store=>({chatOpen:value}))),
}))

export default useStore